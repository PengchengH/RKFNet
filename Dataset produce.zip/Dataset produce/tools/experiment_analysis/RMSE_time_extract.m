function [out] = RMSE_time_extract(model,noise,tail_index,varargin)

    out = struct;
    
    if strcmp(model,'ssg')
        if isstruct(varargin{end})
            opti = varargin{end};
            if isfield(opti,'optname') 
                if strcmp(opti.optname,'GL') || strcmp(opti.optname,'IGGL')        
                    if ~isfield(opti,'num_point')
                        error('num_point should be inputed for GL and IGGL')
                    end
                elseif strcmp(opti.optname,'IS') || strcmp(opti.optname,'IGIS') 
                    if ~isfield(opti,'num_particle')
                        error('num_particle should be inputed for IS and IGIS')
                    end 
                else
                    error('the optname is illegal')
                end
                
            else
                error('the optname should be inputed');
            end
            
        else
            error('the option for ssg is necessary and should be struct');
        end
    end


    if any(strcmp(varargin,'position')) || any(strcmp(varargin,'velocity'))||...
       any(strcmp(varargin,'iteration'))|| any(strcmp(varargin,'sec_ratio'))
        if any(strcmp(varargin,'position'))
            out.prmse=0;
        end
        if any(strcmp(varargin,'velocity'))
            out.vrmse = 0;
        end
        if any(strcmp(varargin,'iteration'))
            out.ite_mean = 0;
        end
        if any(strcmp(varargin,'sec_ratio'))
            out.sed_ratio_mean = 0;
        end
        if any(strcmp(varargin,'time'))
            out.time = 0;
        end
    else
        error('at least input one measure')
    end



    % read file
    tail = tail_index(1);
    
    if strcmp(model,'ssg')
        if strcmp(opti.optname,'GL') || strcmp(opti.optname,'IGGL')
            load(['result/' model '/ns_' noise '_tail_' num2str(tail) '_'...
                 opti.optname '_point_' num2str(opti.num_point) '.mat']);
        elseif strcmp(opti.optname,'IS') || strcmp(opti.optname,'IGIS')
            load(['result/' model '/ns_' noise '_tail_' num2str(tail) '_' ...
                 opti.optname '_npar_' num2str(opti.num_particle) '.mat']);
        end    
    else
        load(['result/' model '/ns_' noise '_tail_' num2str(tail) '.mat']); 
    end
    
    if strcmp(filterout.state,'success')
    
        if isfield(out,'prmse')  
            out.prmse = filterout.prmse;
        end
        if isfield(out,'vrmse')  
            out.vrmse = filterout.vrmse;
        end
        if isfield(out,'ite_mean')  
            out.ite_mean = filterout.ite_mean;
        end  
        if isfield(out,'sed_ratio_mean')  
            out.sed_ratio_mean = filterout.sed_ratio_mean;
        end      
        if isfield(out,'time')  
            out.time = filterout.time;
        end 
        
    elseif strcmp(filterout.state,'fail')
        
        if isfield(out,'prmse')  
            out.prmse = NaN;
        end
        if isfield(out,'vrmse')  
            out.vrmse = NaN;
        end
        if isfield(out,'ite_mean')  
            out.ite_mean = NaN;
        end  
        if isfield(out,'sed_ratio_mean')  
            out.sed_ratio_mean = NaN;
        end      
        if isfield(out,'time')  
            out.time = NaN;
        end 
        
    else
        error('the filterout.state value is illegal');
    end

end

