import torch
from torch.distributions.distribution import Distribution

# the class for multi-dimensional student t distribution
class slash(Distribution):
    def __init__(self, validate_args=None):
        # The distribution name, mean, scale matrix and dof value
        self.name = 'slash'

    
    # scale function
    @staticmethod
    def Ke(x_in):
        x_out = x_in
        return x_out
    
    
    @staticmethod
    def opt(n, dof, eta1):
        # The theoretical solution is available
        alpha = (n + dof) / 2
        beta  = eta1 / 2
        
        if alpha.is_cuda:
            f1 = (torch.special.gammainc(alpha + 1, beta) * torch.exp(torch.lgamma((alpha + 1).cpu()).to(torch.device("cuda:0")))) / (beta**(alpha + 1))
            f2 = (torch.special.gammainc(alpha, beta) * torch.exp(torch.lgamma(alpha.cpu()).to(torch.device("cuda:0")))) / (beta**alpha)
        else:
            f1 = (torch.special.gammainc(alpha + 1, beta) * torch.exp(torch.lgamma(alpha + 1))) / (beta**(alpha + 1))
            f2 = (torch.special.gammainc(alpha, beta) * torch.exp(torch.lgamma(alpha))) / (beta**alpha)
        
        out = {'EK': f1 / f2}
    
        return out

          
      
      

    
    
