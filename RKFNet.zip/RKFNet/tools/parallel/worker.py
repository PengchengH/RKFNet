from Pipeline_HRKF import Pipeline_HRKF
from HRKF_nn import HRKFnn
from MB_rnn import MB_rnn

def worker_train(mylist,process_id):
    
    modelFileName = mylist['modelFileName']
    trainFileName = mylist['trainFileName']
    testFileName  = mylist['testFileName']
    traj_para     = mylist['traj_para']
    train_para    = mylist['train_para']
    Data_collection = mylist['Data_collection']
    train_method    = mylist['train_method']
    
    #event.set()  
    
    HRKF_Pipeline = Pipeline_HRKF(modelFileName, trainFileName, testFileName)
    
    if train_method['nn_name'] == 'HRKFnn':
        HRKF_net = HRKFnn(train_method['nn_name'])
    else:
        HRKF_net = MB_rnn(train_method['nn_name'])
        
    HRKF_net.Build(traj_para, train_method['nn_para'])
    
    para_num = HRKF_net.Para_calculate()
    print('NN:', train_method['nn_name'], ',number of parameters:', para_num)
    
    HRKF_Pipeline.setModel(HRKF_net)
    HRKF_Pipeline.settrain_para(train_para)
    HRKF_Pipeline.NNTrain(Data_collection,train_method,process_id)
    HRKF_Pipeline.NNTest(train_method['nn_name'], traj_para, Data_collection,process_id)


def worker_test(mylist,process_id,test_model=None,device=None):
    
    modelFileName = mylist['modelFileName']
    trainFileName = mylist['trainFileName']
    testFileName  = mylist['testFileName']
    Data_collection = mylist['Data_collection']
    traj_para     = mylist['traj_para']
    train_method    = mylist['train_method']
   
  
    HRKF_Pipeline = Pipeline_HRKF(modelFileName, trainFileName, testFileName)
    HRKF_Pipeline.NNTest(train_method['nn_name'], traj_para, Data_collection,process_id,test_model=test_model,device=device)
