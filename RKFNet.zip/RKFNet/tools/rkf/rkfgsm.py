# -*- coding: utf-8 -*-
"""
Created on Sat Nov 18 12:12:24 2023

@author: hpc
"""

import torch
import matplotlib.pyplot as plt
import time

class rkfgsm:

    def __init__(self, traj_para, md_para, gsm):
        
        # Motion Model       
        self.F   = traj_para['F']
        self.F_T = torch.transpose(self.F, 0, 1)
        self.n   = self.F.size()[0]
        self.Qs  = traj_para['Qs'];

        # Observation Model
        self.H   = traj_para['H']
        self.H_T = torch.transpose(self.H, 0, 1)
        self.m   = self.H.size()[0]
        self.Rs  = traj_para['Rs'];
        
        
        # GMS tools
        self.gsm        = gsm
        
        # model information
        self.model_name = md_para['name']
        self.delta  = md_para['delta'] 
        self.Wdof   = md_para['Wdof']
        self.Wscale = md_para['Wscale']
        
        
        
        # initial information
        self.P0 = traj_para['P0'];
        self.x0 = traj_para['x0'];
        
        
        # Identity Matrix
        self.In = torch.eye(self.n) 
        

    def filtering (self, z, x):
    # def filtering (self, z, x):
        # Parameter reading
        n = self.n
        length = z.size()[2]
        cycle  = z.size()[0]
    
        # gsm_filter related matrix
        x_pos = torch.zeros(cycle, n, length)
        P_pos = torch.zeros(cycle, n, n, length)
    
        for j in range(cycle):
            x_pos[j, :, 0]    = self.x0
            P_pos[j, :, :, 0] = self.P0
    
        K_lamda    = torch.zeros(cycle, length)
        ite        = torch.zeros(cycle, length)
        num_second = torch.zeros(cycle, length)
    
        state = 'success'
    
        start_time = time.process_time()
        for cycle_c in range(cycle):
            
            # print(cycle_c)
            
            for t in range(1, length):
                # extract parameter
                mea = z[cycle_c, :, t]
                xt_ = x_pos[cycle_c, :, t - 1]
                Pt_ = P_pos[cycle_c, :, :, t - 1]
    
                out = self.assimation(mea, xt_, Pt_)
    
                x_pos[cycle_c, :, t]    = out['x_pos']
                P_pos[cycle_c, :, :, t] = out['P_pos']
                K_lamda[cycle_c, t]     = out['K_lamda']
                ite[cycle_c, t]         = out['ite']
                num_second[cycle_c, t]  = out['num_second']
    
                # print(out['P_pos'])
    
                if out['state'] == 'fail':
                    state = out['state']
                    break
    
                # print(t)
    
            if state == 'fail':
                break
            

            
            # plt.figure(1, figsize=(10, 8))

            # plt.subplot(2, 2, 1)
            # plt.plot(x[cycle_c, 0, :].cpu() , x[cycle_c, 1, :].cpu() , '-*k', label='groundtruth')
            # # plt.plot(z[cycle_c, 0, :].cpu(), z[cycle_c, 1, :].cpu(), '-*b', label='measurement')
            # plt.plot(x_pos[ cycle_c, 0, :].cpu(), x_pos[cycle_c, 1, :].cpu(), '-*r', label='GSM')
            # plt.title('trajectory')
            # plt.legend()
            # plt.xlabel('x')
            # plt.ylabel('y')
            
            # # Calculate and plot errors
            # z_RMSE = z[cycle_c, :, :] - x[cycle_c, 0:2, :]
            # z_RMSE = torch.sqrt((z_RMSE[0, :]**2 + z_RMSE[1, :]**2) / 2)
            # Position_RMSE = x_pos[cycle_c, 0:2, :] - x[cycle_c, 0:2, :]
            # Position_RMSE = torch.sqrt((Position_RMSE[0, :]**2 + Position_RMSE[1, :]**2) / 2)
            
            # plt.subplot(2, 2, 2)
            # plt.plot(torch.log(z_RMSE).cpu(), '-*b', label='measurement')
            # plt.plot(torch.log(Position_RMSE).cpu(), '-*r', label='GSM')
            # plt.title('Error')
            # plt.legend()
            # plt.xlabel('time')
            # plt.ylabel('LOG error')
            
            # # Display means of errors
            # print(torch.mean(z_RMSE).item())
            # print(torch.mean(Position_RMSE).item())
            
            # # Plot univariate part
            # # plt.subplot(2, 2, 3)
            # # plt.semilogy(traj['s'][cycle_c, :], '-og', label='scale')
            # # plt.semilogy(1. / K_lamda[cycle_c, :], '-or', label='estimation')
            # # plt.title('univariate part')
            # # plt.legend()
            # # plt.xlabel('time')
            # # plt.ylabel('value')
            
            # plt.tight_layout()
            # plt.show()
            
            # a = 1
            
        end_time = time.process_time()   
    
        if state == 'fail':
            
            RKF = {'state': 'fail'}
            
        else:
            
            
            RKF = {'state': 'success',             
                    'time': (end_time - start_time) / cycle,  # time for every cycle
                    'iteration': ite,
                    'num_second': num_second
                    }
            
            x_error  = x_pos - x
            p_error2 = torch.pow(x_error[:,0,:],2) + torch.pow(x_error[:,1,:],2)
            v_error2 = torch.pow(x_error[:,2,:],2) + torch.pow(x_error[:,3,:],2)
            
            RKF['MAE_p']  = torch.mean(torch.sqrt(p_error2))
            RKF['MAE_v']  = torch.mean(torch.sqrt(v_error2))   
            RKF['TMAE_p']  = torch.mean(torch.sqrt(p_error2), dim=0)
            RKF['TMAE_v']  = torch.mean(torch.sqrt(v_error2), dim=0)  
            
            RKF['RMSE_p'] = torch.sqrt(torch.mean(p_error2))
            RKF['RMSE_v'] = torch.sqrt(torch.mean(v_error2))              
            RKF['TRMSE_p'] = torch.sqrt(torch.mean(p_error2, dim=0))
            RKF['TRMSE_v'] = torch.sqrt(torch.mean(v_error2, dim=0))
    
        return RKF
            

    # Assimilation function
    def assimation(self, z, xt_, Pt_):
        
        # Default set
        ite_num = 50
               
        # Modeling parameter
        dof = self.delta
        uk  = self.Wdof
        Uk  = self.Wscale
            
        # Estimate Prior distribution
        Pn_pri = self.F @ Pt_ @ self.F.t() + self.Qs  # norminal prediction covariance
    
        # Initialization
        E_lamda = torch.zeros(ite_num)
        E_lamda[0] = 1
        E_K_lamda  = torch.zeros(ite_num)
        E_K_lamda[0] = self.gsm.Ke(E_lamda[0])  # K(lamda)=1/lamda;
    
        E_R_inv = torch.zeros(self.m, self.m, ite_num)
    
        if uk <= self.m + 1:  # give minimal value of uk
            uk = self.m + 1 + 0.1
            
        E_R_inv[:, :, 0] = (uk - self.m - 1) * torch.inverse(Uk)
    
        P_pos = torch.zeros(self.n, self.n, ite_num)
        Rm    = torch.zeros(self.m, self.m, ite_num)
    
        x_pos = torch.zeros(self.n, ite_num)
        x_pri = torch.zeros(self.n, ite_num)
    
        num_second = 0  # number of iterations by second strategy;
        
     
        # EM method
        for i in range(ite_num - 1):
            # Calculate q^(i+1)[xk]
            Rm[:, :, i] = torch.inverse(E_R_inv[:, :, i]) / E_K_lamda[i]
    
            x_pri[:, i + 1] = self.F @ xt_
            K = Pn_pri @ self.H.t() @ torch.inverse (self.H @ Pn_pri @ self.H.t() + Rm[:, :, i])
            x_pos[:, i + 1]    = x_pri[:, i + 1] + K @ (z - self.H @ x_pri[:, i + 1])
            P_pos[:, :, i + 1] = (torch.eye(self.n) - K @ self.H) @ Pn_pri
    
            # Calculate q^(i+1)[Xi]; q^(i+1)[lamda]
            B = (z - self.H @ x_pos[:, i + 1]) @ (z - self.H @ x_pos[:, i + 1]).t() + self.H @ P_pos[:, :, i + 1] @ self.H.t()
            b = z - self.H @ x_pos[:, i + 1]
    
            # Based on GH Variance Gamma Distribution lamda;
            eta1 = torch.trace(B @ E_R_inv[:, :, i])
            
            if self.gsm.name == 'ssg':
                opti = self.gsm.opt_IGIS(self.gsm.num_series, self.gsm.num_particle, self.m, dof, eta1)
                
            elif self.gsm.name == 'vg' or self.gsm.name == 'slash' or self.gsm.name == 'stdt':
                opti = self.gsm.opt(self.m, dof, eta1)
                
            else:
                raise RuntimeError("The name of GSM cannot be identified from current library")
                
            E_K_lamda[i + 1] = opti['EK']
            
            if 'indicator' in opti:
                num_second += opti['indicator']
    
            D = E_K_lamda[i + 1] * (self.H @ P_pos[:, :, i + 1] @ self.H.t() + b @ b.t())
    
            # Calculate SIGMA and R;
            ukm = uk + 1
            Ukm = Uk + D
    
            E_R_inv[:, :, i + 1] = (ukm - self.m - 1) * torch.inverse(Ukm)
    
            if i > 4:
                x_diff = torch.sum(torch.abs(x_pos[:, i-2 : i+2] - x_pos[:, i-3 : i+1]))
                P_diff = torch.sum(torch.abs(P_pos[:, :, i-2 : i+2] - P_pos[:, :, i-3 : i+1]))
                K_lamda_diff = torch.sum(torch.abs(E_K_lamda[i-2 : i+2] - E_K_lamda[i-3 : i+1]))
    
                x_abs = torch.sum(torch.abs(x_pos[:, i-2 : i+2]))
                P_abs = torch.sum(torch.abs(P_pos[:, :, i-2 : i+2]))
                K_lamda_abs = torch.sum(torch.abs(E_K_lamda[i-2 : i+2]))
    
                if x_diff / x_abs < 1e-2 and P_diff / P_abs < 1e-2 and K_lamda_diff / K_lamda_abs < 1e-2:
                    break
    
            if torch.any(torch.isnan(x_pos[:, i + 1])) or torch.any(torch.isnan(P_pos[:, :, i + 1])) \
                    or torch.any(torch.isnan(E_K_lamda[i + 1])):
                break
    
        out = {
            'x_pos': x_pos[:, i + 1],
            'P_pos': P_pos[:, :, i + 1],
            'K_lamda': E_K_lamda[i + 1],
            'ite': i,
            'num_second': num_second
        }
    
        if torch.any(torch.isnan(out['x_pos'])) or torch.any(torch.isnan(out['P_pos'])) or \
                torch.isnan(out['K_lamda']):
            out['state'] = 'fail'
        else:
            out['state'] = 'success'
    
        return out
            
        

            
            
            