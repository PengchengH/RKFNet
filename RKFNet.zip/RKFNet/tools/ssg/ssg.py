import torch
from torch.distributions.distribution import Distribution
torch.pi = torch.acos(torch.zeros(1)).item() * 2 # which is 3.1415927410125732
import scipy
from scipy.stats import levy_stable

# the class for multi-dimensional student t distribution
class ssg(Distribution):
    def __init__(self, validate_args=None):
        # The distribution name, mean, scale matrix and dof value
        self.name = 'ssg'
    
    
    # scale function
    @staticmethod
    def Ke(x_in):
        x_out = 1/x_in
        return x_out
    
    
    # inverse-Gamma-series-based strategy
    def opt_IGIS(self, num_series, num_particle, n, dof, eta1):

        alpha1 = dof / 2
        
        C  = torch.zeros(num_series)
        m  = torch.zeros(num_series)
        cm = torch.zeros(num_series)
        b  = eta1 / 2
        
        F_sum = torch.zeros(num_series + 1)
        
        for k in range(1, num_series):
            
           
            C[k - 1] = torch.real(torch.exp(
                        torch.log(self.rcu_to_ccp(alpha1**2/b)) 
                        + torch.log(self.rcu_to_ccp(torch.tensor((-1)**(k + 1)))) 
                        + torch.lgamma((k * alpha1).cpu()) 
                        - torch.lgamma(torch.tensor(k).cpu()) 
                        - torch.log( self.rcu_to_ccp(scipy.special.gamma((1 - k * alpha1).cpu())) )
                        + torch.log( self.rcu_to_ccp(k / (b**(k * alpha1))) )
                        ))
            
            # Pytorch basic function cannot support this
            # C[k - 1] = torch.real(torch.exp(
            #             torch.log(alpha1**2/b) 
            #             + torch.log(complex(torch.tensor((-1)**(k + 1)))) 
            #             + torch.lgamma(k * alpha1) 
            #             - torch.lgamma(torch.tensor(k)) 
            #             - torch.lgamma( 1 - k * alpha1 )
            #             + torch.log( self.rcu_to_ccp(k / (b**(k * alpha1))) )
            #             ))
            
            m[k - 1]  = (alpha1 * k + n / 2) / b
            cm[k - 1] = C[k - 1] * m[k - 1]
            F_sum[k]  = F_sum[k - 1] + cm[k - 1]
            
            if k > 4 and torch.sum(torch.abs(torch.real(cm[k - 5:k]))) / torch.sum(torch.abs(torch.real(F_sum[k - 4:k + 1]))) < 1e-2:
                break

        if k < num_series - 1:
            
            C     = torch.real(C)
            F_sum = torch.real(F_sum)
            EK    = torch.real(F_sum[k]) / torch.sum(C[0:k])
        
            method_indicator = 0  # Indicate using the IG strategy
            
        else:
           
            out1 = self.opt_IS(num_particle, n, dof, eta1)
            EK   = out1['EK']
        
            method_indicator = 1  # Indicate using the second strategy

        return {'EK': EK, 'indicator': method_indicator}
   
    
    # importance-sampling-based strategy
    def opt_IS(self, num_particle, n, dof, eta1):
        
        alpha1 = dof / 2
        gam    = (torch.cos(torch.pi * dof / 4))**(2 / dof)
        
        x  = levy_stable.rvs(alpha=alpha1.cpu(), beta=1, loc=0, scale=gam.cpu(), size=num_particle, random_state=None)
        kx = torch.tensor(self.Ke(x))
        
        weight = torch.exp(-0.5 * eta1 * kx) * (kx**(n / 2))
        weight = weight / torch.sum(weight)
        
        result = {'EK': torch.sum(kx * weight)}
        
        return result
    
    
    # transfer cuda real number to complex number on to cpu
    @staticmethod
    def rcu_to_ccp(x):
        x = torch.tensor(float(x.cpu()), dtype=torch.complex64).cpu()
        return x
    

    
          
      
      

    
    
