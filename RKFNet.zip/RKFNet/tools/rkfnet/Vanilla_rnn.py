"""# **Class: KalmanNet**"""

import torch
import torch.nn as nn
torch.pi = torch.acos(torch.zeros(1)).item() * 2 # which is 3.1415927410125732


class Vanilla_rnn(nn.Module):

    ###################
    ### Constructor ###
    ###################
    # initialize the attributes of an object
    def __init__(self):
        # initializes the parent class object into the child class
        super().__init__()
        # initialize GPU if available
        # self.device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
        self.name = 'Vanilla_rnn'
        
        
    @staticmethod
    def signed_log(input):
        return torch.sign(input) * torch.log(torch.abs(input) + 1.0)
    
    
    @staticmethod
    def signed_exp(input):
        return torch.sign(input) * torch.exp(torch.abs(input))

    ###################
    ### Build Model ###
    ###################
    def Build(self, traj_para):
        
        # F and H matrix
        self.InitSzstemDznamics(traj_para['F'], traj_para['H'], traj_para['Qs'])

        self.H0 = 2
        self.H1 = 32
        self.H2 = 4  # scale parameter

        self.InitHRKFNet()
        
        # Loss function part
        self.lgdof    = nn.parameter.Parameter(torch.tensor([0.0]))
        self.lgsigma  = nn.parameter.Parameter(torch.tensor([0.0]))
        
 
  
    def InitSzstemDznamics(self, F, H, _):
        # Set State Transition Matrix
        self.F   = F
        self.H   = H 
        # 
        
        self.m   = self.H.size()[0]
        # self.Rn  = torch.zeros(self.m,self.m)


    def InitHRKFNet(self):          
        self.RK_RNN = nn.RNN(self.H0, self.H1, num_layers=2)  
        self.RK_L1  = nn.Linear(self.H1, self.H2, bias=True)        
        
    
    def to_cup (self):
        self = self.to('cpu')       
        self.F   = self.F.cpu()    
        self.H   = self.H.cpu()       
        # self.Rn  = self.Rn.cpu() 
        
        
    #####################################
    ### Forward and related functions ###
    #####################################
    def forward(self, xt_, Pt_, zt):
        
        [x_pos] = self.Net_step(zt)
        
        return [torch.squeeze(x_pos), Pt_]



    # Kalman Gain Step
    def Net_step(self, zt):
        
        if zt.dim() == 1:             
            zt  = torch.unsqueeze(zt, dim=0)
            
        # Through Neural Network
        net_in  = torch.squeeze(self.signed_log(zt))    
        La1_out,_ = self.RK_RNN(net_in) 
        x_pos     = self.signed_exp(self.RK_L1(La1_out)) 
 
       
        return [x_pos]

    
    

        