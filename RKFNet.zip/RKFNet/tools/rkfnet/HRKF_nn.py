"""# **Class: KalmanNet**"""

import torch
import torch.nn as nn
torch.pi = torch.acos(torch.zeros(1)).item() * 2 # which is 3.1415927410125732


class HRKFnn(nn.Module):

    ###################
    ### Constructor ###
    ###################
    # initialize the attributes of an object
    def __init__(self, name):
        # initializes the parent class object into the child class
        super().__init__()
        # initialize GPU if available
        # self.device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
        self.name = name
    
    def signed_log(self,input):
        
        return torch.sign(input) * torch.log(torch.abs(input) + 1.0)

    ###################
    ### Build Model ###
    ###################
    def Build(self, traj_para, nn_para):
        
        # F and H matrix
        self.InitSzstemDznamics(traj_para['F'], traj_para['H'], traj_para['Qs'])
        
        self.H0 = nn_para['H0']
        self.H1 = nn_para['H1']
        self.H2 = nn_para['H2']
        self.H3 = nn_para['H3']
        self.H4 = nn_para['H4']


        self.InitHRKFNet()
        
        # Loss function part
        self.lgdof    = nn.parameter.Parameter(torch.tensor([0.0]))
        self.lgsigma  = nn.parameter.Parameter(torch.tensor([0.0]))

        self.Ln_small = nn.parameter.Parameter(torch.rand(self.m,self.m)/300)
        
 
  
    def InitSzstemDznamics(self, F, H, Qs):
        # Set State Transition Matrix
        self.F   = F
        self.F_T = torch.transpose(self.F, 0, 1)
        self.n   = self.F.size()[0]
        
        self.Qs  = Qs
    

        # Set Observation Matrix
        self.H   = H
        self.H_T = torch.transpose(self.H, 0, 1)
        self.m   = self.H.size()[0]
        
 
        self.Rn  = torch.zeros(self.m,self.m)
        
        # Identity Matrix
        self.In = torch.eye(self.n)


    def InitHRKFNet(self):   

        
        self.RK_L1  = nn.Linear(self.H0, self.H1, bias=True)
        self.RK_L2  = nn.Linear(self.H1, self.H2, bias=True)
        self.RK_L3  = nn.Linear(self.H2, self.H3, bias=True)
        self.RK_L4  = nn.Linear(self.H3, self.H4, bias=True)
        
        self.RK_NL = nn.LeakyReLU(0.1)
    
    def Para_calculate(self):
        
        para_num = self.H0*self.H1 + self.H1*self.H2 + self.H2*self.H3 \
                    + self.H3*self.H4 + self.H1 + self.H2 + self.H3 +self.H4 \
                    + pow(self.m,2) + 2     
                                   
        return para_num
    
    def to_cup (self):
        self = self.to('cpu')
        
        self.F   = self.F.cpu() 
        self.F_T = self.F_T.cpu() 
        
        self.Qs  = self.Qs.cpu() 
    
        self.H   = self.H.cpu() 
        self.H_T = self.H_T.cpu() 
        
        
        self.Rn  = self.Rn.cpu() 
        
     
        self.In = self.In.cpu() 

        
        
        
    #####################################
    ### Forward and related functions ###
    #####################################
    def forward(self, xt_, Pt_, zt, Outscale=False):
        if Outscale:
            [x_pos,P_pos,s] = self.Net_step(xt_, Pt_, zt, Outscale)
            return [torch.squeeze(x_pos),P_pos,s]
        else:
            [x_pos,P_pos] = self.Net_step(xt_, Pt_, zt, Outscale)
            return [torch.squeeze(x_pos),P_pos]
        



    # Kalman Gain Step
    def Net_step(self, xt_, Pt_, zt, Outscale=False):
        
        if xt_.dim() == 2:  
            
            bun = xt_.size(dim=0)   
            
        elif  xt_.dim() == 1:  
            
            bun = 1
            xt_ = torch.unsqueeze(xt_, dim=0)
            Pt_ = torch.unsqueeze(Pt_, dim=0)
            zt  = torch.unsqueeze(zt, dim=0)
            
            
        
        # Forcast
        x_pri = torch.matmul(self.F, torch.unsqueeze(xt_, dim=2))        
        P_pri = torch.matmul(torch.matmul(self.F, Pt_), self.F_T) + self.Qs
        z_pri = torch.matmul(self.H, x_pri)
        R_pri = torch.matmul(torch.matmul(self.H,P_pri),self.H_T)
        
        dz    = torch.unsqueeze(zt, dim=2) - z_pri

        
        # Through Neural Network
        net_in = torch.zeros(bun, self.H0)
        net_in[:, 0:2] = torch.squeeze(self.signed_log(dz))
        net_in[:, 2]   = torch.squeeze(self.signed_log(R_pri[:,0, 0]))
        net_in[:, 3]   = torch.squeeze(self.signed_log(R_pri[:,1, 1]))
        net_in[:, 4]   = torch.squeeze(self.signed_log(R_pri[:,0, 1]))


        La1_out = self.RK_NL(self.RK_L1(net_in))
        La2_out = self.RK_NL(self.RK_L2(La1_out)) 
        La3_out = self.RK_NL(self.RK_L3(La2_out))
        L4_out  = self.RK_L4(La3_out)
        L4_out  = torch.clamp(L4_out, max=100.0) # limite the maximum number
 

        # Calculate and normalise Rn 
        Ln = 300*self.Ln_small
        
        self.Rn = torch.matmul(Ln,torch.transpose(Ln, 0, 1))

        
        # Kalman Data Assimilation
        s = torch.exp(2*L4_out)

        R = torch.unsqueeze(s, dim=2)*self.Rn.repeat(bun, 1, 1)
        
        
        # Kalman Gain
        KGain = torch.matmul(torch.matmul(P_pri,self.H_T), torch.linalg.inv(R_pri+R)) 
        x_pos = x_pri + torch.matmul(KGain, dz)
        P_pos = torch.matmul((self.In-torch.matmul(KGain,self.H)),P_pri)
        
        if Outscale:
            return [x_pos,P_pos,torch.squeeze(s)]    
        else:
            return [x_pos,P_pos]

    
    

        