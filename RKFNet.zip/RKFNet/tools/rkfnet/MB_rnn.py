
"""# **Class: KalmanNet**"""

import torch
import torch.nn as nn
torch.pi = torch.acos(torch.zeros(1)).item() * 2 # which is 3.1415927410125732


class MB_rnn(nn.Module):

    ###################
    ### Constructor ###
    ###################
    # initialize the attributes of an object
    def __init__(self, name):
        # initializes the parent class object into the child class
        super().__init__()
        # initialize GPU if available
        # self.device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
        self.name = name
    
    @staticmethod
    def signed_log(input):
        return torch.sign(input) * torch.log(torch.abs(input) + 1.0)
    
    @staticmethod
    def signed_exp(input):
        return torch.sign(input) * (torch.exp(torch.abs(input))-1.0)

    ###################
    ### Build Model ###
    ###################
    def Build(self, traj_para, nn_para):
        
        # F and H matrix
        self.InitSzstemDznamics(traj_para['F'], traj_para['H'], traj_para['Qs'])

        self.H0 = nn_para['H0']
        self.H1 = nn_para['H1']
        self.H2 = nn_para['H2']  # scale parameter
        
        self.layer = nn_para['layer']

        self.InitHRKFNet()
        
        # Loss function part
        self.lgdof    = nn.parameter.Parameter(torch.tensor([0.0]))
        self.lgsigma  = nn.parameter.Parameter(torch.tensor([0.0]))
        
 
  
    def InitSzstemDznamics(self, F, H, _):
        # Set State Transition Matrix
        self.F   = F
        self.H   = H 
        
        self.m   = self.H.size()[0]
        # self.Rn  = torch.zeros(self.m,self.m)


    def InitHRKFNet(self):  
        if self.name == 'MB_vanilla_RNN':              
            self.RK_RNN = nn.RNN(self.H0, self.H1, num_layers=self.layer) 
            
        elif self.name == 'MB_GRU':            
            self.RK_RNN = nn.GRU(self.H0, self.H1, num_layers=self.layer)
            
        elif self.name == 'MB_LSTM':
            self.RK_RNN = nn.LSTM(self.H0, self.H1, num_layers=self.layer)
            
        else:
            raise RuntimeError("The name of nn model cannot be identified")
            
        self.RK_L1  = nn.Linear(self.H1, self.H2, bias=True)   
        
        
    # calculate the number of parameters of a neural network;
    def Para_calculate(self):
        
        if self.name == 'MB_vanilla_RNN':
            para_num = 2*self.H1+self.H0*self.H1+pow(self.H1,2)  \
                        + (self.layer-1)*(2*self.H1+2*pow(self.H1,2)) \
                        + self.H2+self.H1*self.H2     
                        
        elif self.name == 'MB_GRU':
            para_num = 6*self.H1+3*self.H0*self.H1+3*pow(self.H1,2)  \
                        + (self.layer-1)*(6*self.H1+6*pow(self.H1,2)) \
                        + self.H2+self.H1*self.H2
                        
        elif self.name == 'MB_LSTM':
            para_num = 8*self.H1+4*self.H0*self.H1+4*pow(self.H1,2)  \
                        + (self.layer-1)*(8*self.H1+8*pow(self.H1,2)) \
                        + self.H2+self.H1*self.H2   
                        
        else:
            raise RuntimeError("The name of nn model cannot be identified")
        
        return para_num
        
    
    def to_cup (self):
        self = self.to('cpu')       
        self.F   = self.F.cpu()    
        self.H   = self.H.cpu()       
        # self.Rn  = self.Rn.cpu() 
        
        
    #####################################
    ### Forward and related functions ###
    #####################################
    def forward(self, xt_, Pt_, zt):
        
        [x_pos] = self.Net_step(xt_, zt)
        
        return [torch.squeeze(x_pos), Pt_]



    # Kalman Gain Step
    def Net_step(self, xt_, zt):
        
        if xt_.dim() == 2:              
            bun = xt_.size(dim=0)   
            
        elif xt_.dim() == 1:              
            bun = 1
            xt_ = torch.unsqueeze(xt_, dim=0)
            zt  = torch.unsqueeze(zt, dim=0)
        
        # Forcast
        x_pri = torch.matmul(self.F, torch.unsqueeze(xt_, dim=2)) 
        dzt   = zt - torch.squeeze(torch.matmul(self.H, x_pri), dim=2)
        
        
        # Through Neural Network
        net_in = torch.zeros(1, bun, self.H0)
        net_in[0, :, 0:2] = self.signed_log(dzt)
        
     
        La1_out,_ = self.RK_RNN(net_in) 
        x_incre   = self.signed_exp(self.RK_L1(La1_out))
        
        x_pos = torch.squeeze(x_pri) + torch.squeeze(x_incre)
        
        # print('torch.squeeze(x_pri)')
        # print(torch.squeeze(x_pri))
        # print('x_incre')
        # print(x_incre)
        # print('xt_')
        # print(xt_)
        # print('zt')
        # print(zt)
        # print('dzt')
        # print(dzt)
        # print('net_in')
        # print(net_in)
        # print('net_in.size()')
        # print(net_in.size())
        # print('x_incre')
        # print(x_incre)
        # print('x_pos')
        # print(x_pos)
        
        
 
        return [x_pos]
    
    
    
    
    
    

    
    

        