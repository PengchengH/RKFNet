import torch
import torch.nn as nn
import matplotlib as mpl
import matplotlib.pyplot as plt
import time
import os



class Pipeline_HRKF:

    def __init__(self, modelFileName, trainFileName, testFileName):
        super().__init__()       
        self.modelFileName = modelFileName 
        self.trainFileName = trainFileName
        self.testFileName  = testFileName
     

    #RKFnet model
    def setModel(self, model):
        self.model = model

    def settrain_para(self, train_para):
        
        self.N_B          = train_para['n_Batch']  # Number of Samples in Batch
        self.N_Epochs     = train_para['n_Epochs']  # Number of Training Epochs
        self.weightDecay  = train_para['weightDecay'] # L2 Weight Regularization - Weight Decay
        self.learningRate = train_para['learningRate'] # Learning Rate
            
        self.L1 = nn.L1Loss(size_average=None, reduce=None, reduction='mean')
        self.L2 = nn.MSELoss(size_average=None, reduce=None, reduction='mean')
        
        self.optimizer = torch.optim.Adam(self.model.parameters(), lr=self.learningRate, weight_decay=self.weightDecay)
        self.ExpLR     = torch.optim.lr_scheduler.StepLR(self.optimizer, step_size=400, gamma=0.5)
 
    
    def ST_Loss(self, error, dof, sigma):
        Loss = -torch.lgamma((dof+1.0)/2) + torch.lgamma(dof/2)\
                + torch.log(torch.sqrt(dof*torch.pi)*sigma)\
                + (dof+1.0)/2*torch.log(1.0+ torch.pow(error, 2.0)/(dof*torch.pow(sigma,2.0)))
        return Loss
    
    
    def Loss_Computer(self, x , z_next, Loss_name):
        pre_error = (torch.squeeze(torch.matmul(self.model.H, torch.matmul(self.model.F,x))) - z_next)
        
        if Loss_name == 'L1':
            Loss = self.L1(pre_error,torch.zeros(pre_error.size()))
            
        elif Loss_name == 'L2':
            Loss = self.L2(pre_error,torch.zeros(pre_error.size()))
            
        elif Loss_name == 'ST':
            dof   = torch.exp(300*self.model.lgdof)
            sigma = torch.exp(300*self.model.lgsigma) 
            Loss  = torch.mean(self.ST_Loss(pre_error,dof,sigma))
      
        return Loss

    ################
    ### Training ###
    ################
    def NNTrain(self, DC, train_method, ID):
       
        # read paramters
        N_E  = DC['train_x'].size(dim=0)
        n    = DC['train_x'].size(dim=1)  
        
        length = DC['train_x'].size(dim=2)-1
        
        dim_p = DC['dim_p']
        dim_v = DC['dim_v']
        
        Loss_name  = train_method['Loss']
        P_mini     = train_method['P_mini']
        train_mode = train_method['train_mode']
        
             
        # training and cv performance dict
        cv_sum    = {'epoch': {'LossdB': torch.zeros([self.N_Epochs]), 
                              'MAE_p': torch.zeros([self.N_Epochs]),
                              'MAE_v': torch.zeros([self.N_Epochs]),
                              'RMSE_p': torch.zeros([self.N_Epochs]),
                              'RMSE_v': torch.zeros([self.N_Epochs]) }, 
                     'opt': {'index':  torch.zeros(1),
                             'best_LossdB': torch.zeros(1), 
                             'MAE_p': torch.zeros(1), 
                             'MAE_v': torch.zeros(1), 
                             'RMSE_p': torch.zeros(1), 
                             'RMSE_v': torch.zeros(1), 
                             }   }        
        
        train_sum = {'epoch': {'LossdB': torch.zeros([self.N_Epochs]), 
                              'MAE_p': torch.zeros([self.N_Epochs]),
                              'MAE_v': torch.zeros([self.N_Epochs]),
                              'RMSE_p': torch.zeros([self.N_Epochs]),
                              'RMSE_v': torch.zeros([self.N_Epochs]), }, 
                     'opt': {'index':  torch.zeros(1),
                             'LossdB': torch.zeros(1), 
                             'MAE_p': torch.zeros(1), 
                             'MAE_v': torch.zeros(1), 
                             'RMSE_p': torch.zeros(1), 
                             'RMSE_v': torch.zeros(1), 
                             } }

        
        
        # Results for the best and current cv
        x_out_best = torch.zeros(self.N_B, n, length)

        # Train the network with the increase of Epochs
        for ti in range(0, self.N_Epochs):
            # Scheduled Sampling training method
            if train_mode == 'NSS':  
                P_truth = 0.0               
            else:
                P_truth = max(P_mini,1-3*ti/self.N_Epochs)               

            #################################
            ### Validation Sequence Batch ###
            #################################
            self.model.eval()  
            torch.cuda.empty_cache()
            
            # para_num = self.model.Para_calculate()
            # print(para_num)
        
            
            with torch.no_grad():

                x_out_cv = torch.zeros(self.N_B, n, length) 
                P_out_cv = torch.zeros(self.N_B, n, n, length)
                               
                x_out_cv[:,:,0]   = DC['cv_x_pos'][:,:,0]                   
                P_out_cv[:,:,:,0] = DC['cv_P_pos'][:,:,:,0]

                for t in range(1, length):
                    [x_out_cv[:,:, t],P_out_cv[:,:,:,t]] = self.model(x_out_cv[:,:, t-1], 
                           P_out_cv[:,:,:,t-1], DC['cv_z'][:,:, t])  
                    
                # MAE and RMSE errors 
                x_error  = x_out_cv-DC['cv_x'][:,:,0:length]
                p_error2 = torch.pow(x_error[:,dim_p[0],:],2) + torch.pow(x_error[:,dim_p[1],:],2)
                v_error2 = torch.pow(x_error[:,dim_v[0],:],2) + torch.pow(x_error[:,dim_v[1],:],2)
                
                cv_sum['epoch']['MAE_p'][ti]  = torch.mean(torch.sqrt(p_error2)).item()
                cv_sum['epoch']['MAE_v'][ti]  = torch.mean(torch.sqrt(v_error2)).item()                
                cv_sum['epoch']['RMSE_p'][ti] = torch.sqrt(torch.mean(p_error2)).item() 
                cv_sum['epoch']['RMSE_v'][ti] = torch.sqrt(torch.mean(v_error2)).item()
                          
                # Loss
                if self.model.name == 'HRKFnn':
                    Loss_cv = self.Loss_Computer(x_out_cv , DC['cv_z'][:,:,1:length+1] , Loss_name) \
                            + 0.1*self.L2(torch.linalg.det(self.model.Rn),torch.tensor(1.0))
                elif self.model.name == 'MB_vanilla_RNN' or self.model.name == 'MB_GRU' or self.model.name == 'MB_LSTM':
                    Loss_cv = self.Loss_Computer(x_out_cv , DC['cv_z'][:,:,1:length+1] , Loss_name) 
                else:
                    raise RuntimeError("The name of nn model cannot be identified")
            
                cv_sum['epoch']['LossdB'][ti] = 10* torch.log10(Loss_cv).item()       
                
                
                if ti <1:   
                    # update best sequence, model and Loss
                    x_out_best = x_out_cv                    
                    self.best_model = self.model                  
                    Loss_best = Loss_cv   
                    
                else:
                    Loss_best = self.Loss_Computer(x_out_best, DC['cv_z'][:,:,1:length+1] , Loss_name)
                    if Loss_cv < Loss_best:
                        
                        x_out_best = x_out_cv                    
                        self.best_model = self.model                  
                        Loss_best = Loss_cv
                        
                        cv_sum['opt']['index']  = ti
                        cv_sum['opt']['best_LossdB'] = cv_sum['epoch']['LossdB'][ti]
                        cv_sum['opt']['MAE_p']  = cv_sum['epoch']['MAE_p'][ti]
                        cv_sum['opt']['MAE_v']  = cv_sum['epoch']['MAE_v'][ti]             
                        cv_sum['opt']['RMSE_p'] = cv_sum['epoch']['RMSE_p'][ti] 
                        cv_sum['opt']['RMSE_v'] = cv_sum['epoch']['RMSE_v'][ti]

                                

            ###############################
            ### Training Sequence Batch ###
            ###############################
            # Training Mode
            self.model.train()

            # select the training input randomly           
            x_out_train = torch.zeros(self.N_B, n, length)
            P_out_train = torch.zeros(self.N_B, n, n, length)
            
            # sample a bunch of data
            n_e = torch.randint(0, N_E - 1, (self.N_B,))
            
            x_out_train[:,:,0]   = DC['train_x_pos'][n_e, :, 0]
            P_out_train[:,:,:,0] = DC['train_P_pos'][n_e, :, :, 0]
                
            input_x = torch.zeros(self.N_B, n)
            input_P = torch.zeros(self.N_B, n, n) 
            
            for t in range(1, length): 
                
                if P_truth > 0:
                    batch_sample = torch.bernoulli(P_truth * torch.ones(self.N_B) )
                    address1     = torch.nonzero(batch_sample)
                    address2     = torch.nonzero(torch.ones(self.N_B)-batch_sample)
                        
                    input_x[address1,:]   = DC['train_x_pos'][n_e[address1], :, t-1]
                    input_P[address1,:,:] = DC['train_P_pos'][n_e[address1],:,:,t-1]
                        

                    input_x[address2,:]   = x_out_train[address2,:,t-1]
                    input_P[address2,:,:] = P_out_train[address2,:,:,t-1]
                    
                else:
                    input_x = x_out_train[:,:,t-1]
                    input_P = P_out_train[:,:,:,t-1]
                        
                [x_out_train[:,:,t],P_out_train[:,:,:,t]] =\
                      self.model(input_x, input_P, DC['train_z'][n_e, :, t])

            
            if self.model.name == 'HRKFnn':
                LOSS = self.Loss_Computer(x_out_train[:,:,1:length] , DC['train_z'][n_e,:,2:length+1] , Loss_name) \
                        + 0.1*self.L2(torch.linalg.det(self.model.Rn),torch.tensor(1.0))
            elif self.model.name == 'MB_vanilla_RNN' or self.model.name == 'MB_GRU' or self.model.name == 'MB_LSTM':
                LOSS = self.Loss_Computer(x_out_train[:,:,1:length] , DC['train_z'][n_e,:,2:length+1] , Loss_name)
            else:
                raise RuntimeError("The name of nn model cannot be identified")
            
    
            # MAE and RMSE errors 
            x_error  = x_out_train-DC['train_x'][n_e,:,0:length]
            p_error2 = torch.pow(x_error[:,dim_p[0],:],2) + torch.pow(x_error[:,dim_p[1],:],2)
            v_error2 = torch.pow(x_error[:,dim_v[0],:],2) + torch.pow(x_error[:,dim_v[1],:],2)
            
            train_sum['epoch']['MAE_p'][ti]  = torch.mean(torch.sqrt(p_error2)).item()
            train_sum['epoch']['MAE_v'][ti]  = torch.mean(torch.sqrt(v_error2)).item()                
            train_sum['epoch']['RMSE_p'][ti] = torch.sqrt(torch.mean(p_error2)).item() 
            train_sum['epoch']['RMSE_v'][ti] = torch.sqrt(torch.mean(v_error2)).item()
            
            # Loss
            train_sum['epoch']['LossdB'][ti] = 10* torch.log10(LOSS).item()

            
            # Update optimal results and save the optimal model;             
            if (train_sum['epoch']['LossdB'][ti] < train_sum['opt']['LossdB'] or ti<1):
                
                train_sum['opt']['index']  = ti
                train_sum['opt']['LossdB'] = train_sum['epoch']['LossdB'][ti]
                train_sum['opt']['MAE_p']  = train_sum['epoch']['MAE_p'][ti]
                train_sum['opt']['MAE_v']  = train_sum['epoch']['MAE_v'][ti]             
                train_sum['opt']['RMSE_p'] = train_sum['epoch']['RMSE_p'][ti] 
                train_sum['opt']['RMSE_v'] = train_sum['epoch']['RMSE_v'][ti]


            ##################
            ### Optimizing ###
            ##################
            self.optimizer.zero_grad()

            LOSS.backward()

            # Optimizer makes an update to its parameters
            self.optimizer.step()
            

            # Update Learning rate   
            self.ExpLR.step()
            
            
            
            ########################
            ### Training Summary ###
            ########################  
            # lr = self.ExpLR.get_last_lr()
            # print('epoch:', ti, "Learning Rate:",lr)
            # print( "Train Loss:", train_sum['epoch']['LossdB'][ti], "[dB]", 
            #         "CV Loss:", cv_sum['epoch']['LossdB'][ti], "[dB]")
            # if (ti > 1):
            #     d_train = train_sum['epoch']['LossdB'][ti] - train_sum['epoch']['LossdB'][ti-1]
            #     d_cv    = cv_sum['epoch']['LossdB'][ti] - cv_sum['epoch']['LossdB'][ti-1]
            #     print("diff Train Loss:", d_train, "[dB]", "diff CV Loss:", d_cv, "[dB]")
            #     print("Optimal idx:", cv_sum['opt']['index'], "Optimal RMSE position:", cv_sum['opt']['RMSE_p'],"[m]")
                
            # print("CV RMSE position:", cv_sum['epoch']['RMSE_p'][ti], "[m]")
            # print("best_LossdB", str(cv_sum['opt']['best_LossdB']) ,"[dB]")
            
            # print('Rn',self.model.Rn)
            

        os.makedirs(os.path.dirname( self.modelFileName + '_ID_'+ str(ID)+ '.pt'), exist_ok=True)
        torch.save(self.best_model, self.modelFileName + '_ID_'+ str(ID)+ '.pt')
        
        os.makedirs(os.path.dirname( self.trainFileName+ '_ID_' + str(ID)+ '.pt'), exist_ok=True)
        torch.save({'train_sum': train_sum, 'cv_sum': cv_sum}, self.trainFileName+ '_ID_' + str(ID)+ '.pt')



    ###############
    ### Testing ###
    ###############
    def NNTest(self, model_name, traj_para, DC, ID, test_model=None, device=None):
        
        # read the parameters
        cycle  = DC['test_x'].size(dim=0)
        n      = DC['test_x'].size(dim=1)            
        length = DC['test_x'].size(dim=2)
        
        dim_p = DC['dim_p']
        dim_v = DC['dim_v']
        
        test_sum = { }
        
        # print(device)
        self.model = torch.load(self.modelFileName+ '_ID_'+ str(ID)+ '.pt', map_location=device)

        
        if test_model=='with cpu':
            self.model.to_cup()
        
        # evaluation mode
        self.model.eval()
        
        torch.cuda.empty_cache()
        with torch.no_grad():
                
            x_out_test = torch.zeros(cycle, n, length) 
            P_out_test = torch.zeros(cycle, n, n, length) 
            s_out_test = torch.zeros(cycle, length) 
            x_out_test[:,:,0]   = DC['test_x_pos'][:,:,0]                   
            P_out_test[:,:,:,0] = DC['test_P_pos'][:,:,:,0]
            
            # x_out_test_1 = torch.zeros(cycle, n, length) 
            # P_out_test_1 = torch.zeros(cycle, n, n, length)           
            # x_out_test_1[:,:,0]   = DC['test_x_pos'][:,:,0]                   
            # P_out_test_1[:,:,:,0] = DC['test_P_pos'][:,:,:,0]
                        
                
            if test_model=='with cpu':  
                start_time = time.process_time()
                
            else:
                start_event = torch.cuda.Event(enable_timing=True)
                end_event   = torch.cuda.Event(enable_timing=True)
                start_event.record()

            # for cycle_c in range(cycle):
            #     for t in range(1, length):
            #         if model_name == 'HRKFnn':
            #             [x_out_test[cycle_c,:, t],P_out_test[cycle_c,:,:,t],s_out_test[cycle_c, t]] = self.model(x_out_test[cycle_c,:, t-1], 
            #                                             P_out_test[cycle_c,:,:,t-1], DC['test_z'][cycle_c,:, t], Outscale=True)
                    
            #         elif  model_name == 'MB_vanilla_RNN' or  model_name == 'MB_GRU' or  model_name == 'MB_LSTM':
            #             [x_out_test[cycle_c,:, t],P_out_test[cycle_c,:,:,t]] = self.model(x_out_test[cycle_c,:, t-1], 
            #                                             P_out_test[cycle_c,:,:,t-1], DC['test_z'][cycle_c,:, t]) 
                # print(cycle_c)
            for t in range(1, length):
                if model_name == 'HRKFnn':
                    [x_out_test[:,:, t],P_out_test[:,:,:,t],s_out_test[:, t]] = self.model(x_out_test[:,:, t-1], 
                                                    P_out_test[:,:,:,t-1], DC['test_z'][:,:, t], Outscale=True)
                elif  model_name == 'MB_vanilla_RNN' or  model_name == 'MB_GRU' or  model_name == 'MB_LSTM':
                    [x_out_test[:,:, t],P_out_test[:,:,:,t]] = self.model(x_out_test[:,:, t-1], 
                                                    P_out_test[:,:,:,t-1], DC['test_z'][:,:, t]) 
                
            
            if test_model=='with cpu': 
                end_time = time.process_time()  
                test_sum['time'] = (end_time - start_time) / cycle
                
            else:
                end_event.record()
                torch.cuda.synchronize() 
            
                elapsed_time_ms = start_event.elapsed_time(end_event)
                test_sum['time']  = elapsed_time_ms/1000/ cycle
                
            # MAE and RMSE errors 
            x_error  = x_out_test-DC['test_x'][:,:,0:length]
                       
            p_error2 = torch.pow(x_error[:,dim_p[0],:],2) + torch.pow(x_error[:,dim_p[1],:],2)
            v_error2 = torch.pow(x_error[:,dim_v[0],:],2) + torch.pow(x_error[:,dim_v[1],:],2)
            
            test_sum['MAE_p']   = torch.mean(torch.sqrt(p_error2))
            test_sum['MAE_v']   = torch.mean(torch.sqrt(v_error2))
            test_sum['TMAE_p']  = torch.mean(torch.sqrt(p_error2), dim=0)
            test_sum['TMAE_v']  = torch.mean(torch.sqrt(v_error2), dim=0)              
            test_sum['RMSE_p']  = torch.sqrt(torch.mean(p_error2))
            test_sum['RMSE_v']  = torch.sqrt(torch.mean(v_error2))
            test_sum['TRMSE_p'] = torch.sqrt(torch.mean(p_error2, dim=0))
            test_sum['TRMSE_v'] = torch.sqrt(torch.mean(v_error2, dim=0))
            if model_name == 'HRKFnn':
                # test_sum['det_err'] = torch.log(torch.mean( torch.abs(  s_out_test[:,1:length].unsqueeze(-1).unsqueeze(-1) *self.model.Rn
                #                            - DC['test_s'][:,1:length].unsqueeze(-1).unsqueeze(-1)*traj_para['Rs']  )))
                test_sum['det_err'] = torch.mean(torch.log(torch.abs(torch.det(self.model.Rn)*(s_out_test[:,1:length]**2) 
                                            - torch.det(traj_para['Rs'])*(DC['test_s'][:,1:length]**2))))
        
        os.makedirs(os.path.dirname( self.testFileName+ '_ID_' + str(ID)+ '.pt' ), exist_ok=True)    
        torch.save({'test_sum': test_sum}, self.testFileName+ '_ID_' + str(ID)+ '.pt')
        
        
        
        
        
