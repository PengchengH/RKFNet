import torch
import scipy.io


def DataLoader_matlab_data(datafile, trajfile, train_para):
  
    # read data
    traj  = scipy.io.loadmat(trajfile)    
    filte = scipy.io.loadmat(datafile)
    
    
    # read modelling parameters 
    # For kftncm, the properties do not exist, skip by function 'try'
    try:
        md_para = {'name' : traj['md']['name'][0][0][0],
                   'modelling_method': traj['md']['modelling'][0][0][0],
                   'delta': torch.tensor(traj['md']['delta'][0][0][0][0]),
                   'Wdof' : torch.tensor(traj['md']['Wdof'][0][0][0][0]),
                   'Wscale' : torch.tensor(traj['md']['Wscale'][0][0]),
                   
                   }
    except KeyError:
        md_para = {}
        
    
    # trajectory information
    traj_para = {}
    traj_para['T']  = torch.tensor(traj['traj']['T'][0,0]).to(torch.float64)
    traj_para['F']  = torch.tensor(traj['traj']['F'][0,0]).to(torch.float64)
    traj_para['H']  = torch.tensor(traj['traj']['H'][0,0]).to(torch.float64)
    traj_para['length']  = torch.tensor(traj['traj']['length'][0,0]).to(torch.float64)

    traj_para['Qs']  = torch.tensor(traj['traj']['Qs'][0,0]).to(torch.float64)
    traj_para['Rs']  = torch.tensor(traj['traj']['Rs'][0,0]).to(torch.float64)
    

    traj_para['P0']  = torch.diag(torch.tensor([25.0,25.0,25.0,25.0])).to(torch.float64)
    traj_para['x0']  = torch.tensor([0.0,0.0,10.0,10.0]).to(torch.float64)
    
    
    
    #data set
    N_E  = train_para['N_E'] 
    N_CV = train_para['N_CV'] 
    N_T  = train_para['N_T']
    
    
    Data_collection = { }

    Data_collection['train_x'] = torch.tensor(traj['traj']['x'][0,0])[:,:,0:N_E].transpose(0, 2).transpose(1, 2)
    Data_collection['train_z'] = torch.tensor(traj['traj']['z'][0,0])[:,:,0:N_E].transpose(0, 2).transpose(1, 2)
    Data_collection['train_s'] = torch.tensor(traj['traj']['s'][0,0])[:,0:N_E].transpose(0, 1)
       
     
    Data_collection['cv_x'] = torch.tensor(traj['traj']['x'][0,0])[:,:,N_E:N_E+N_CV].transpose(0, 2).transpose(1, 2)
    Data_collection['cv_z'] = torch.tensor(traj['traj']['z'][0,0])[:,:,N_E:N_E+N_CV].transpose(0, 2).transpose(1, 2)
    Data_collection['cv_s'] = torch.tensor(traj['traj']['s'][0,0])[:,N_E:N_E+N_CV].transpose(0, 1)
    
       
    Data_collection['test_x'] = torch.tensor(traj['traj']['x'][0,0])[:,:,N_E+N_CV:N_E+N_CV+N_T].transpose(0, 2).transpose(1, 2)
    Data_collection['test_z'] = torch.tensor(traj['traj']['z'][0,0])[:,:,N_E+N_CV:N_E+N_CV+N_T].transpose(0, 2).transpose(1, 2)
    Data_collection['test_s'] = torch.tensor(traj['traj']['s'][0,0])[:,N_E+N_CV:N_E+N_CV+N_T].transpose(0, 1)
    
    
    if filte['filterout']['state'][0][0][0] == 'success':
        Data_collection['train_x_pos'] = torch.tensor(filte['filterout']['x_pos'][0,0])[:,:,0:N_E].transpose(0, 2).transpose(1, 2)
        Data_collection['train_P_pos'] = torch.tensor(filte['filterout']['P_pos'][0,0])[:,:,:,0:N_E].transpose(0, 3).transpose(2, 3).transpose(1, 2)
           
        Data_collection['cv_x_pos'] = torch.tensor(filte['filterout']['x_pos'][0,0])[:,:,N_E:N_E+N_CV].transpose(0, 2).transpose(1, 2)
        Data_collection['cv_P_pos'] = torch.tensor(filte['filterout']['P_pos'][0,0])[:,:,:,N_E:N_E+N_CV].transpose(0, 3).transpose(2, 3).transpose(1, 2)
           
        Data_collection['test_x_pos'] = torch.tensor(filte['filterout']['x_pos'][0,0])[:,:,N_E+N_CV:N_E+N_CV+N_T].transpose(0, 2).transpose(1, 2)
        Data_collection['test_P_pos'] = torch.tensor(filte['filterout']['P_pos'][0,0])[:,:,:,N_E+N_CV:N_E+N_CV+N_T].transpose(0, 3).transpose(2, 3).transpose(1, 2)

        

   
    return [Data_collection, md_para, traj_para]

        
        
        
        
        

