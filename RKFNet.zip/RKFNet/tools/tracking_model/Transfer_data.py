import torch
import scipy.io
import numpy as np


def DataLoader(model_name, trajfile, datafile, train_para):
  
    # read data
    traj  = scipy.io.loadmat(trajfile) 
    
    
    
    # read modelling parameters 
    # For kftncm, the properties do not exist, skip by function 'try'
    if model_name == 'kftncm':
        
        md_para = {}
        
    elif model_name == 'slash' or model_name == 'ssg' or model_name == 'stdt':
        
        filte = scipy.io.loadmat(datafile)
        
        md_para = {'name' : traj[model_name + '_modelling']['name'][0][0][0],
                   'modelling_method': traj[model_name + '_modelling']['modelling'][0][0][0],
                   'delta': torch.tensor(traj[model_name + '_modelling']['delta'][0][0][0][0]),
                   'Wdof' : torch.tensor(traj[model_name + '_modelling']['Wdof'][0][0][0][0]),
                   'Wscale' : torch.tensor(traj[model_name + '_modelling']['Wscale'][0][0]),         
                   }
    
    elif model_name == 'ssg_precise' or model_name == 'stdt_precise':
        
        md_para = {}
        
        filte = scipy.io.loadmat(datafile)
        
    else:

        raise RuntimeError("The name of GSM cannot be identified")
        
    
    # trajectory information
    traj_para = {}
    traj_para['T']  = torch.tensor(traj['traj']['T'][0,0]).to(torch.float64)
    traj_para['F']  = torch.tensor(traj['traj']['F'][0,0]).to(torch.float64)
    traj_para['H']  = torch.tensor(traj['traj']['H'][0,0]).to(torch.float64)
    traj_para['length']  = torch.tensor(traj['traj']['length'][0,0]).to(torch.float64)

    traj_para['Qs']  = torch.tensor(traj['traj']['Qs'][0,0]).to(torch.float64)
    traj_para['Rs']  = torch.tensor(traj['traj']['Rs'][0,0]).to(torch.float64)
    

    traj_para['P0']  = torch.tensor(traj['traj']['P0'][0,0]).to(torch.float64)
    traj_para['x0']  = torch.tensor(traj['traj']['x0'][0,0]).transpose(0, 1).to(torch.float64)
    
    
    
    #data set
    N_E  = train_para['N_E'] 
    N_CV = train_para['N_CV'] 
    N_T  = train_para['N_T']
    
    
    Data_collection = { }

    Data_collection['train_x'] = torch.tensor(traj['traj']['x'][0,0])[:,:,0:N_E].transpose(0, 2).transpose(1, 2)
    Data_collection['train_z'] = torch.tensor(traj['traj']['z'][0,0])[:,:,0:N_E].transpose(0, 2).transpose(1, 2)
    Data_collection['train_s'] = torch.tensor(traj['traj']['s'][0,0].astype(np.float64))[:,0:N_E].transpose(0, 1)
       
     
    Data_collection['cv_x'] = torch.tensor(traj['traj']['x'][0,0])[:,:,N_E:N_E+N_CV].transpose(0, 2).transpose(1, 2)
    Data_collection['cv_z'] = torch.tensor(traj['traj']['z'][0,0])[:,:,N_E:N_E+N_CV].transpose(0, 2).transpose(1, 2)
    Data_collection['cv_s'] = torch.tensor(traj['traj']['s'][0,0].astype(np.float64))[:,N_E:N_E+N_CV].transpose(0, 1)
    
       
    Data_collection['test_x'] = torch.tensor(traj['traj']['x'][0,0])[:,:,N_E+N_CV:N_E+N_CV+N_T].transpose(0, 2).transpose(1, 2)
    Data_collection['test_z'] = torch.tensor(traj['traj']['z'][0,0])[:,:,N_E+N_CV:N_E+N_CV+N_T].transpose(0, 2).transpose(1, 2)
    Data_collection['test_s'] = torch.tensor(traj['traj']['s'][0,0].astype(np.float64))[:,N_E+N_CV:N_E+N_CV+N_T].transpose(0, 1)
    
    if model_name == 'slash' or model_name == 'ssg' or model_name == 'stdt':
        if filte['filterout']['state'][0][0][0] == 'success':
            Data_collection['train_x_pos'] = torch.tensor(filte['filterout']['x_pos'][0,0])[:,:,0:N_E].transpose(0, 2).transpose(1, 2)
            Data_collection['train_P_pos'] = torch.tensor(filte['filterout']['P_pos'][0,0])[:,:,:,0:N_E].transpose(0, 3).transpose(2, 3).transpose(1, 2)
               
            Data_collection['cv_x_pos'] = torch.tensor(filte['filterout']['x_pos'][0,0])[:,:,N_E:N_E+N_CV].transpose(0, 2).transpose(1, 2)
            Data_collection['cv_P_pos'] = torch.tensor(filte['filterout']['P_pos'][0,0])[:,:,:,N_E:N_E+N_CV].transpose(0, 3).transpose(2, 3).transpose(1, 2)
               
            Data_collection['test_x_pos'] = torch.tensor(filte['filterout']['x_pos'][0,0])[:,:,N_E+N_CV:N_E+N_CV+N_T].transpose(0, 2).transpose(1, 2)
            Data_collection['test_P_pos'] = torch.tensor(filte['filterout']['P_pos'][0,0])[:,:,:,N_E+N_CV:N_E+N_CV+N_T].transpose(0, 3).transpose(2, 3).transpose(1, 2) 
    
    if model_name == 'ssg_precise' or model_name == 'stdt_precise':
        if filte['filterout']['state'][0][0][0] == 'success':               
            Data_collection['test_x_pos'] = torch.tensor(filte['filterout']['x_pos'][0,0]).transpose(0, 2).transpose(1, 2)
 

    # display training
    # x_error  = Data_collection['train_x_pos']-Data_collection['train_x']
    # p_error2 = torch.pow(x_error[:,0,:],2) + torch.pow(x_error[:,1,:],2)    
    # MAE_p    = torch.mean(torch.sqrt(p_error2))
    # RMSE_p   = torch.sqrt(torch.mean(p_error2))
    # print('MAE_p:'+ str(MAE_p) )
    # print('RMSE_p:'+ str(RMSE_p) )
   
    return [Data_collection, md_para, traj_para]

        
        
        
        
        

