import torch
from torch.distributions.multivariate_normal import MultivariateNormal
from stdt import stdt

class trajmodel:

    def __init__(self, traj_para, noise_para):

        # Motion Model       
        self.F  = traj_para['F']
        self.F_T = torch.transpose(self.F, 0, 1)
        self.n  = self.F.size()[0]
        self.Qs = traj_para['Qs'];

        # Observation Model
        self.H  = traj_para['H']
        self.H_T = torch.transpose(self.H, 0, 1)
        self.m  = self.H.size()[0]
        self.Rs = traj_para['Rs'];

        self.model_name = noise_para['noise_name'];
        self.dof        = noise_para['dof'];
        
        
        # initial information
        self.P0 = traj_para['P0'];
        self.x0 = traj_para['x0'];
        
        self.In = torch.eye(self.n)


    #########################
    ### Generate Sequence ###
    #########################
    def GenerateSequence(self, length):
        
        # Pre allocate an array for current state and observation
        x = torch.zeros(self.n, length)      
        z = torch.zeros(self.m, length)
        
        # signal noise
        dist = MultivariateNormal(torch.zeros(self.n), self.Qs)
        w    = dist.rsample(torch.tensor([length])).T
        
        # measurement noise
        dist  = stdt(torch.zeros(self.m), self.Rs, self.dof)
        [v,s] = dist.rdn(torch.tensor([length]))
        
        # initial state
        dist = MultivariateNormal(torch.zeros(self.n), self.P0)
        x[:, 0] = self.x0 + dist.rsample(torch.tensor([1]))
        z[:, 0] = self.H.matmul(x[:, 0]) + v[:, 0]


        # Generate Sequence Iteratively
        for t in range(1, length):
            ########################
            #### State Evolution ###
            ########################            
            # Process Noise
            x[:, t] = self.F.matmul(x[:, t-1])+ w[:, t-1]
            
            z[:, t] = self.H.matmul(x[:, t]) + v[:, t]
        
        return [x, z, s]
            


    ######################
    ### Generate Batch ###
    ######################

    def GenerateBatch(self, size, length):

        # Allocate Empty Array for Input
        z = torch.empty(size, self.m, length)
        
        # True target position and veliction
        x = torch.empty(size, self.n, length)
        
        # True target scale parameter
        s = torch.empty(size, 1, length)
        
        # Produce the Trajectory
        for i in range(0, size):
            # Generate Sequence
            [x[i, :, :], z[i, :, :], s[i, :, :]] = self.GenerateSequence(length)
       
        return [x, z, s]
      

            
            
            
            
            

