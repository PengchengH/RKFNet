import torch
import scipy.io
import numpy as np


def DataLoader(model_name, train_para, trajfile_train = None, trajfile_test =None,
               datafile_train=None, datafile_test=None):
  
    
    # read Trajectory
    
    if trajfile_train != None:
        traj_train  = scipy.io.loadmat(trajfile_train)   
    if trajfile_test != None:
        traj_test   = scipy.io.loadmat(trajfile_test) 
    
    
    # trajectory information
    traj_para = {}
    if trajfile_train != None: 
        traj_para['T']  = torch.tensor(traj_train['traj']['T'][0,0]).to(torch.float64)
        traj_para['F']  = torch.tensor(traj_train['traj']['F'][0,0]).to(torch.float64)
        traj_para['H']  = torch.tensor(traj_train['traj']['H'][0,0]).to(torch.float64)
        traj_para['length']  = torch.tensor(traj_train['traj']['length'][0,0]).to(torch.float64)
    
        traj_para['Qs']  = torch.tensor(traj_train['traj']['Qs'][0,0]).to(torch.float64)
        traj_para['Rs']  = torch.tensor(traj_train['traj']['Rs'][0,0]).to(torch.float64)
        
        traj_para['P0']  = torch.tensor(traj_train['traj']['P0'][0,0]).to(torch.float64)
        traj_para['x0']  = torch.tensor(traj_train['traj']['x0'][0,0]).transpose(0, 1).to(torch.float64)    
    elif trajfile_test != None:
        traj_para['T']  = torch.tensor(traj_test['traj']['T'][0,0]).to(torch.float64)
        traj_para['F']  = torch.tensor(traj_test['traj']['F'][0,0]).to(torch.float64)
        traj_para['H']  = torch.tensor(traj_test['traj']['H'][0,0]).to(torch.float64)
        traj_para['length']  = torch.tensor(traj_test['traj']['length'][0,0]).to(torch.float64)
    
        traj_para['Qs']  = torch.tensor(traj_test['traj']['Qs'][0,0]).to(torch.float64)
        traj_para['Rs']  = torch.tensor(traj_test['traj']['Rs'][0,0]).to(torch.float64)
        
        traj_para['P0']  = torch.tensor(traj_test['traj']['P0'][0,0]).to(torch.float64)
        traj_para['x0']  = torch.tensor(traj_test['traj']['x0'][0,0]).transpose(0, 1).to(torch.float64)    
    
    #data set
    N_E  = train_para['N_E'] 
    N_CV = train_para['N_CV'] 
    N_T  = train_para['N_T']
    
    
    Data_collection = { }
    
    if trajfile_train != None: 
        Data_collection['train_x'] = torch.tensor(traj_train['traj']['x'][0,0])[:,:,0:N_E].transpose(0, 2).transpose(1, 2)
        Data_collection['train_z'] = torch.tensor(traj_train['traj']['z'][0,0])[:,:,0:N_E].transpose(0, 2).transpose(1, 2)
        Data_collection['train_s'] = torch.tensor(traj_train['traj']['s'][0,0].astype(np.float64))[:,0:N_E].transpose(0, 1)
           
         
        Data_collection['cv_x'] = torch.tensor(traj_train['traj']['x'][0,0])[:,:,N_E:N_E+N_CV].transpose(0, 2).transpose(1, 2)
        Data_collection['cv_z'] = torch.tensor(traj_train['traj']['z'][0,0])[:,:,N_E:N_E+N_CV].transpose(0, 2).transpose(1, 2)
        Data_collection['cv_s'] = torch.tensor(traj_train['traj']['s'][0,0].astype(np.float64))[:,N_E:N_E+N_CV].transpose(0, 1)
    
    if trajfile_test != None:   
        Data_collection['test_x'] = torch.tensor(traj_test['traj']['x'][0,0]).transpose(0, 2).transpose(1, 2)
        Data_collection['test_z'] = torch.tensor(traj_test['traj']['z'][0,0]).transpose(0, 2).transpose(1, 2)
        Data_collection['test_s'] = torch.tensor(traj_test['traj']['s'][0,0].astype(np.float64)).transpose(0, 1)
        
    
    # read RKF filtering results
    if trajfile_train != None: 
        filte_train, md_para = dataload(model_name, traj_train, datafile_train)
    if trajfile_test != None:  
        filte_test , md_para = dataload(model_name, traj_test, datafile_test)
    
    if model_name == 'slash' or model_name == 'ssg' or model_name == 'stdt' or model_name =='kftncm':
        
        if trajfile_train != None:
            if filte_train['filterout']['state'][0][0][0] == 'success':    
                Data_collection['train_x_pos'] = torch.tensor(filte_train['filterout']['x_pos'][0,0])[:,:,0:N_E].transpose(0, 2).transpose(1, 2)
                Data_collection['train_P_pos'] = torch.tensor(filte_train['filterout']['P_pos'][0,0])[:,:,:,0:N_E].transpose(0, 3).transpose(2, 3).transpose(1, 2)
                   
                Data_collection['cv_x_pos'] = torch.tensor(filte_train['filterout']['x_pos'][0,0])[:,:,N_E:N_E+N_CV].transpose(0, 2).transpose(1, 2)
                Data_collection['cv_P_pos'] = torch.tensor(filte_train['filterout']['P_pos'][0,0])[:,:,:,N_E:N_E+N_CV].transpose(0, 3).transpose(2, 3).transpose(1, 2)   
            else:
                print('there is failed filtering results')
        if trajfile_test != None:   
            if filte_test['filterout']['state'][0][0][0] == 'success':
                Data_collection['test_x_pos'] = torch.tensor(filte_test['filterout']['x_pos'][0,0]).transpose(0, 2).transpose(1, 2)
                Data_collection['test_P_pos'] = torch.tensor(filte_test['filterout']['P_pos'][0,0]).transpose(0, 3).transpose(2, 3).transpose(1, 2) 
                if model_name !='kftncm':
                    Data_collection['test_R_pos'] = torch.tensor(filte_test['filterout']['R_pos'][0,0]).transpose(0, 2).transpose(1, 3).transpose(0, 1) 
            else:
                print('there is failed filtering results')
    
    if model_name == 'ssg_precise' or model_name == 'stdt_precise':
        if trajfile_test != None:
            if filte_test['filterout']['state'][0][0][0] == 'success':               
                Data_collection['test_x_pos'] = torch.tensor(filte_test['filterout']['x_pos'][0,0]).transpose(0, 2).transpose(1, 2)
                Data_collection['test_R_pos'] = torch.tensor(filte_test['filterout']['R_pos'][0,0]).transpose(0, 2).transpose(1, 3).transpose(0, 1)


    Data_collection['dim_p'] = [0, 3]
    Data_collection['dim_v'] = [1, 4]

    # # display training
    # # x_error  = Data_collection['train_x_pos']-Data_collection['train_x']
    # x_error  = Data_collection['cv_x_pos']-Data_collection['cv_x']
    # p_error2 = torch.pow(x_error[:,0,:],2) + torch.pow(x_error[:,3,:],2)    
    # # MAE_p    = torch.mean(torch.sqrt(p_error2))
    # RMSE_p   = torch.sqrt(torch.mean(p_error2))
    # # print('MAE_p:'+ str(MAE_p) )
    # print(model_name+'RMSE_p:'+ str(RMSE_p) )
   
    return [Data_collection, md_para, traj_para]

        
def dataload(model_name, traj, datafile):
 
    # read modelling parameters 
    # For kftncm, the properties do not exist, skip by function 'try'
    if model_name == 'kftncm':
        
        md_para = {}
        filte = scipy.io.loadmat(datafile)
        
    elif model_name == 'slash' or model_name == 'ssg' or model_name == 'stdt':
        
        filte = scipy.io.loadmat(datafile)
        
        md_para = {'name' : traj[model_name + '_modelling']['name'][0][0][0],
                   'modelling_method': traj[model_name + '_modelling']['modelling'][0][0][0],
                   'delta': torch.tensor(traj[model_name + '_modelling']['delta'][0][0][0][0]),
                   'Wdof' : torch.tensor(traj[model_name + '_modelling']['Wdof'][0][0][0][0]),
                   'Wscale' : torch.tensor(traj[model_name + '_modelling']['Wscale'][0][0]),         
                   }
    
    elif model_name == 'ssg_precise' or model_name == 'stdt_precise':
        
        md_para = {}
        
        filte = scipy.io.loadmat(datafile)
        
    else:
    
        raise RuntimeError("The name of GSM cannot be identified")    
    
    return filte, md_para
        
        
        

