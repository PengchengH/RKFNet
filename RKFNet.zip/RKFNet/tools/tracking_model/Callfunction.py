# -*- coding: utf-8 -*-
"""
Created on Mon Jan  1 22:32:54 2024

@author: hpc
"""
import os
import torch

from Transfer_data import  DataLoader
from rkfgsm import rkfgsm
from kftncm import kftncm
from stdt import stdt
from slash import slash
from ssg import ssg


def Callfunction(RKF_para,index_filter, index_noise,index_dof):
    
    #read parameters
    Filters = RKF_para['Filters']
    noise   = RKF_para['noise']
    num_series = RKF_para['num_series']
    num_particle = RKF_para['num_particle']
    train_para = RKF_para['train_para']
    
    trajFolderName = RKF_para['trajFolderName']
    dataFolderName = RKF_para['dataFolderName']
    resultFolderName = RKF_para['resultFolderName']

    
    # Noise environment
    noise_name = noise['noise_index'][index_noise]
    dof        = noise['dof_index'][index_noise][index_dof]
    
    

    ###############################################################
    ### Download or Generate Target Trajectory and Measurements ###
    ###############################################################
               
    trajName       = 'ns_' + noise_name + '_tail_' + str(dof)  
    trajFileName   = trajFolderName + trajName + '.mat'
    
    
    if Filters[index_filter] == 'ssg' :
        dataName = 'ns_'+ noise_name +'_tail_' + str(dof) + '_IGIS_npar_100'
    else:
        dataName = 'ns_'+ noise_name +'_tail_' + str(dof) 
    
    dataFileName = dataFolderName + dataName + '.mat'          
    
    # print("Traj Load")
            
    [Data_collection, md_para, traj_para] = DataLoader(Filters[index_filter], trajFileName, dataFileName, train_para)
    
    
    ##########################
    ## Traditional filters ###
    ##########################
    if Filters[index_filter] == 'stdt':
        GSM  = stdt()        
    elif Filters[index_filter] == 'slash':
        GSM  = slash()    
    elif Filters[index_filter] == 'ssg':
        GSM  = ssg()
        GSM.num_series   = num_series 
        GSM.num_particle = num_particle
    elif Filters[index_filter] == 'kftncm':
        RKFGSM = kftncm(traj_para)
    else:
        raise RuntimeError("The name of GSM cannot be identified")
    
    
    if Filters[index_filter] == 'stdt' or Filters[index_filter] == 'slash' or Filters[index_filter] == 'ssg':
        RKFGSM  = rkfgsm(traj_para, md_para, GSM)
        
        
    # print("Filtering_test")
    if Filters[index_filter] == 'kftncm':
        out    = RKFGSM.filtering(Data_collection['test_z'], Data_collection['test_x'], Data_collection['test_s'])
    elif Filters[index_filter] == 'stdt' or Filters[index_filter] == 'slash' or Filters[index_filter] == 'ssg':
        out     = RKFGSM.filtering(Data_collection['test_z'], Data_collection['test_x'])
        
        
    # print("saving")
    os.makedirs(os.path.dirname( resultFolderName  + dataName + '.pt' ), exist_ok=True)               
    torch.save({'filterout': out }, resultFolderName  + dataName + '.pt')
    
    
    
    