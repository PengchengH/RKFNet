import torch
from torch.distributions.distribution import Distribution

# the class for multi-dimensional student t distribution
class stdt(Distribution):
    def __init__(self, validate_args=None):
        # The distribution name, mean, scale matrix and dof value
        self.name = 'stdt'
    
    # scale function
    @staticmethod
    def Ke(x_in):
        x_out = x_in
        return x_out
    
    # mixing density sampling
    @staticmethod
    def mrdn(dof, num_samp):
        vgentor = torch.distributions.gamma.Gamma(dof/2,dof/2);
        x_out   = vgentor.sample(num_samp);
        return x_out
    
    # student t sampling
    def rdn(self, mu, cov, dof, num_samp):
        L = torch.linalg.cholesky(cov)
        r = torch.normal(0, 1, size=(L.size(dim=0), num_samp))
        r = torch.matmul(L, r)      
        s = self.mrdn(dof, num_samp)
        # s = torch.ones(num_samp)
        x = torch.sqrt(s).T
        r = torch.add(torch.div(r, x).T, mu).T
        scale = torch.reciprocal(s)
        return r, scale
    
    @staticmethod
    def opt(m, dof, eta1):
        out = {'EK': (m + dof) / (eta1 + dof)}
        return out
          
      
      

    
    
