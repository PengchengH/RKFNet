import torch
from torch.distributions.distribution import Distribution

# the class for multi-dimensional student t distribution
class vg(Distribution):
    def __init__(self, validate_args=None):
        # The distribution name, mean, scale matrix and dof value
        self.name = 'vg'
    
    # scale function
    @staticmethod
    def Ke(x_in):
        x_out = x_in
        return x_out
    
    
    @staticmethod
    def opt(n, dof, eta1):
        
        out = {}
        out['EK'] = (n - dof - 2 + torch.sqrt((n - dof - 2) ** 2 + 4 * dof * eta1) ) / (2 * eta1)
        
        return out


          
      
      

    
    
