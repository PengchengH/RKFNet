import torch
import torch.nn as nn
from KFTNCM import KFTNCM
import matplotlib.pyplot as plt

def KFTNCMTest(Traj_model, true_x, true_z, true_s,  N_T):   

    # Filter objective
    Filter = KFTNCM(Traj_model)
    
    # estimated posterior position and covariance
    x_pos = torch.empty(size=[N_T, Traj_model.n, true_z.size()[2]])
    P_pos = torch.empty(size=[N_T, Traj_model.n, Traj_model.n, true_z.size()[2]])
    
    # position and velocity MSE matrix
    MSE_position_linear = torch.empty(N_T)
    MSE_velocity_linear = torch.empty(N_T)
    
    # Loss Function
    loss_fn = nn.MSELoss(reduction='mean') 
    
    
    for j in range(0, N_T):
        [x_pos[j,:,:],P_pos[j,:,:,:]]=Filter.GenerateSequence(true_z[j, :, :], true_s[j, :])
        MSE_position_linear[j] = loss_fn(x_pos[j,0:1,:], true_x[j, 0:1, :]).item()
        MSE_velocity_linear[j] = loss_fn(x_pos[j,2:3,:], true_x[j, 2:3, :]).item()

    # average MSE
    MSE_position_linear_avg = torch.mean(MSE_position_linear)
    # MSE_position_dB_avg = 10 * torch.log10(MSE_position_linear_avg)
    MSE_velocity_linear_avg = torch.mean(MSE_velocity_linear)
    # MSE_velocity_dB_avg = 10 * torch.log10(MSE_velocity_linear_avg)

    # Standard deviation
    # MSE_position_dB_std = torch.std(MSE_position_linear, unbiased=True)
    # MSE_position_dB_std = 10 * torch.log10(MSE_position_dB_std)
    # MSE_velocity_dB_std = torch.std(MSE_velocity_linear, unbiased=True)
    # MSE_velocity_dB_std = 10 * torch.log10(MSE_velocity_dB_std)
    

    # Standard deviation
    print("KFTNCM-position-MSE", MSE_position_linear_avg, "[dB]")
    print("KFTNCM-velocity-MSE", MSE_velocity_linear_avg, "[dB]")

    return [x_pos, P_pos, MSE_position_linear_avg, MSE_velocity_linear_avg]



