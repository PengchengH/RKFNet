"""# **Class: KFTNCM**
"""
import torch
import time
import matplotlib.pyplot as plt

class kftncm:

    def __init__(self, traj_para):
        
        # Motion Model       
        self.F   = traj_para['F']
        self.F_T = torch.transpose(self.F, 0, 1)
        self.n   = self.F.size()[0]
        self.Qs  = traj_para['Qs'];

        # Observation Model
        self.H   = traj_para['H']
        self.H_T = torch.transpose(self.H, 0, 1)
        self.m   = self.H.size()[0]
        self.Rs  = traj_para['Rs'];
        
        # initial information
        self.P0 = traj_para['P0'];
        self.x0 = traj_para['x0'];
        
        # Identity Matrix
        self.In = torch.eye(self.n)
    
    
    def filtering(self, z,  x, s, *args):
        
        length = z.size()[2]
        cycle  = z.size()[0]
        
        # Target state and covariance initialisation
        x_pos = torch.zeros(cycle, self.n, length)
        P_pos = torch.zeros(cycle, self.n, self.n, length)
        
        for j in range(cycle):
            x_pos[j, :, 0]    = self.x0
            P_pos[j, :, :, 0] = self.P0
        
        state = 'success'
        start_time = time.process_time()  
        
        # Filtering
        for cycle_c in range(cycle):
            
            # print(cycle_c)
            
            for t in range(1, length):  
                
                [x_pos[cycle_c,:,t],P_pos[cycle_c,:,:,t]] = self.assimation(torch.squeeze(z[cycle_c,:, t]), s[cycle_c,t], x_pos[cycle_c,:,t-1], P_pos[cycle_c,:,:,t-1])                
                
                if torch.isnan(x_pos[cycle_c,:,t]).any() or torch.isnan(P_pos[cycle_c,:,:,t]).any():
                    state = 'fail'
                    break
                
            if state == 'fail':
                break
            
        # plt.figure(1,figsize=(5, 5), layout='constrained')
        # plt.plot(x_pos[cycle_c,0,:], x_pos[cycle_c,1,:],'ro', linewidth=2.0, markersize=2.0)
        # plt.plot(x[cycle_c,0,:], x[cycle_c,1,:],'bo', linewidth=2.0, markersize=2.0)
        # # plt.plot(z[cycle_c,0,:],z[cycle_c,1,:],'k.', linewidth=2.0, markersize=2.0)
        # plt.pause(1)
        # # a = 1;
        
 
        
        if state == 'fail':
            
            RKF = {'state': 'fail'}
            
        else:
            
            end_time = time.process_time()
            
            RKF = {'state': 'success',
                    'time': (end_time - start_time) / cycle,  # time for every cycle
                  }
            
            x_error = x_pos - x
            p_error2 = torch.pow(x_error[:,0,:],2) + torch.pow(x_error[:,1,:],2)
            v_error2 = torch.pow(x_error[:,2,:],2) + torch.pow(x_error[:,3,:],2)
            
            RKF['MAE_p']   = torch.mean(torch.sqrt(p_error2))
            RKF['MAE_v']   = torch.mean(torch.sqrt(v_error2), dim=0)
            RKF['TMAE_p']  = torch.mean(torch.sqrt(p_error2), dim=0)
            RKF['TMAE_v']  = torch.mean(torch.sqrt(v_error2))                 
            RKF['RMSE_p']  = torch.sqrt(torch.mean(p_error2))
            RKF['RMSE_v']  = torch.sqrt(torch.mean(v_error2))
            RKF['TRMSE_p'] = torch.sqrt(torch.mean(p_error2, dim=0))
            RKF['TRMSE_v'] = torch.sqrt(torch.mean(v_error2, dim=0))

        
            
        return RKF
        

   
    # Predict
    def assimation(self,z,s,xt_,Pt_):
        
        # correct the measurement covariance
        R = s*self.Rs
                
        # Forcast
        x_pri = torch.matmul(self.F, xt_)
        P_pri = torch.matmul(torch.matmul(self.F, Pt_), self.F_T) + self.Qs
        R_pri = torch.matmul(torch.matmul(self.H,P_pri),self.H_T)
        
        # Kalman Gain
        KGain = torch.matmul(torch.matmul(P_pri,self.H_T), torch.linalg.inv(R_pri+R))
        
        # Assimilation
        z_pri = torch.matmul(self.H, x_pri)
        dz    = z - z_pri
        x_pos = x_pri + torch.matmul(KGain, dz)
        P_pos = torch.matmul((self.In-torch.matmul(KGain,self.H)),P_pri)
        
        return [x_pos, P_pos]
    
    def kf_call(traj):
        # Extract factors
        F = traj['F']
        H = traj['H']
        x0 = traj['x0']
        P0 = traj['P0']
    
        z = traj['z']
        s = traj['s']
        Qs = traj['Qs']
        Rs = traj['Rs']
        n = Qs.size(0)
    
        length = traj['length']
        cycle = traj['cycle']
    
        x_pos = torch.zeros(n, length, cycle)
        P_pos = torch.zeros(n, n, length, cycle)
    
        for j in range(cycle):
            x_pos[:, 0, j] = x0[:, j]
            P_pos[:, :, 0, j] = P0[:, :, j]
    
        state = 'success'
    
        tic = torch.cuda.Event(enable_timing=True)
        toc = torch.cuda.Event(enable_timing=True)
        tic.record()
    
        for cycle_c in range(cycle):
            for t in range(1, length):
                mea = z[:, t, cycle_c]
                scale = s[t, cycle_c]
                xt_ = x_pos[:, t-1, cycle_c]
                Pt_ = P_pos[:, :, t-1, cycle_c]
    
                # Assuming you have a PyTorch implementation of kftncm
                xt, Pt = kftncm(xt_, Pt_, mea, scale, Qs, Rs, F, H)
    
                x_pos[:, t, cycle_c] = xt
                P_pos[:, :, t, cycle_c] = Pt
    
                if torch.isnan(xt).any() or torch.isnan(Pt).any():
                    state = 'fail'
                    break
    
            if state == 'fail':
                break
    
        toc.record()
        torch.cuda.synchronize()
        elapsed_time = tic.elapsed_time(toc) / cycle
    
        out = {'state': state, 'x_pos': x_pos, 'time': elapsed_time}
    
        return out


            
        

            
            
            