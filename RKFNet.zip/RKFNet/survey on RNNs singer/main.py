import sys
import os

# add parent directory
current_dir = os.path.abspath(os.getcwd())
parent_dir = os.path.dirname(current_dir)
sys.path.append(parent_dir)


# add tools
sys.path.append(parent_dir+'/tools/tracking_model')
sys.path.append(parent_dir+'/tools/kftncm')
sys.path.append(parent_dir+'/tools/rkfnet')
sys.path.append(parent_dir+'/tools/parallel')
sys.path.append(parent_dir+'/tools/rkf')
sys.path.append(parent_dir+'/tools/stdt')
sys.path.append(parent_dir+'/tools/slash')
sys.path.append(parent_dir+'/tools/vg')
sys.path.append(parent_dir+'/tools/ssg')


import torch
# dev = torch.device("cpu")
# torch.set_default_tensor_type('torch.DoubleTensor')
# print("Running on the CPU")
dev = torch.device("cuda:0") 
torch.set_default_device('cuda:0')
torch.set_default_tensor_type('torch.cuda.DoubleTensor')
print("Running on the GPU")
torch.pi = torch.acos(torch.zeros(1)).item() * 2 # which is 3.1415927410125732
from Transfer_data_singer import  DataLoader
from worker import worker_train, worker_test
import torch.multiprocessing as mp



# Constant parameters
modelFolder = 'result/'

num_processes = 5

#######################################
### Matrices for different scenario ###
#######################################
#state-space model
Filters = ['kftncm','stdt','slash','ssg']

noise = {'noise_index': ['gm', 'stdt', 'ssg'],
          'dof_index':[[3, 10, 100, 1000, 10000, 100000, 1000000, 10000000, 100000000],
                       [0.3, 0.5, 0.7, 0.9, 1.2, 1.7, 2.5, 3.5, 6],
                       [0.3, 0.5, 0.7, 0.9, 1.1, 1.3, 1.5, 1.7, 1.85]] }

#Training method
Loss_select   = ['L1', 'L2', 'ST']
P_truth_index = [0.0, 0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1.0]
train_mode    = ['NSS','SS']

# parameters for RKF-SGaS
num_series   = 30 
num_particle = 100

# Number of lengthraining Examples, CV and Test
train_para = {}
train_para['n_Epochs'] = 2000
train_para['n_Batch']  = 200 

train_para['learningRate'] = 2e-4

train_para['weightDecay']  = 1e-4
train_para['N_E']  = 3200
train_para['N_CV'] = 200
train_para['N_T']  = 200

# Parameter of neural networks
nn_para = {'name': ['HRKFnn', 'MB_vanilla_RNN','MB_GRU','MB_LSTM'],
           'HRKFnn': {'H0':5, 'H1':32, 'H2':64, 'H3':32, 'H4':1},
           'MB_vanilla_RNN':{'H0':2, 'H1':63, 'H2':6, 'layer':1},
           'MB_GRU':  {'H0':2, 'H1':36, 'H2':6, 'layer':1}, 
           'MB_LSTM': {'H0':2, 'H1':31, 'H2':6, 'layer':1} }


    
    
for index_filter in range(3,4):
    for index_noise in range(0,3):
        for index_dof in range(0,9):  
            
            # Noise environment
            noise_name = noise['noise_index'][index_noise]
            dof        = noise['dof_index'][index_noise][index_dof]
            
            noise_para   = {'noise_name':noise_name, 'dof': dof}
            

            ###############################################################
            ### Download or Generate Target Trajectory and Measurements ###
            ###############################################################
            trajFolderName = parent_dir + '/' + 'traj' + '/'  + 'singer' + '/'          
            trajName       = 'ns_' + noise_name + '_tail_' + str(dof) + '.mat'  
            
            trajFileName_train   = trajFolderName + 'train/'+ trajName 
            trajFileName_test    = trajFolderName + 'test/'+ trajName
                        
            dataFolderName_train = parent_dir + '/RKF_filtering_data' + '/singer/train/' + Filters[index_filter] + '/'
            dataFolderName_test  = parent_dir + '/RKF_filtering_data' + '/singer/test/'  + Filters[index_filter] + '/'
            
            if Filters[index_filter] == 'ssg' :
                dataName = 'ns_'+ noise_name +'_tail_' + str(dof) + '_IGIS_npar_100' + '.mat' 
            else:
                dataName = 'ns_'+ noise_name +'_tail_' + str(dof) + '.mat'  
            
            dataFileName_train = dataFolderName_train + dataName   
            dataFileName_test  = dataFolderName_test + dataName   
            
            print("Traj Load")
                    
            [Data_collection, md_para, traj_para] = DataLoader(Filters[index_filter], train_para, trajfile_train = trajFileName_train,
                                                                trajfile_test =trajFileName_test,
                                                                datafile_train=dataFileName_train, datafile_test=dataFileName_test)
            
            # [Data_collection, md_para, traj_para] = DataLoader(Filters[index_filter], train_para, 
            #                                                     trajfile_test =trajFileName_test,
            #                                                     datafile_test=dataFileName_test)

            ###############################
            ###  Neural network methods ###
            ###############################                
            train_method = {}
   
            for index_nn in range(0,4):
                for index_Loss in range(2,3):
                    for index_p in range(0,1):
                        for index_mode in range(1,2):  
                            
                            if (train_mode[index_mode] == 'NSS' and P_truth_index[index_p] == 0.0) or \
                                  train_mode[index_mode] == 'SS':
                                    
                                train_method = {'Filter':Filters[index_filter],
                                                'noise' :noise['noise_index'][index_noise],
                                                'dof'   :noise['dof_index'][index_noise][index_dof],
                                                'nn_name': nn_para['name'][index_nn],
                                                'nn_para': nn_para[nn_para['name'][index_nn]],
                                                'Loss':Loss_select[index_Loss],
                                                'P_mini':P_truth_index[index_p],
                                                'train_mode':train_mode[index_mode]} 
                                
                                # print(train_method ) 
                                
                                
                                modelName  =  train_method['train_mode'] + '_' + 'pmin' + str(train_method['P_mini']) + '_' + train_method['Loss'] \
                                                    + '_md_' + train_method['Filter'] + '_ns_' + train_method['noise']+ '_dof'+ str(train_method['dof'])
                                modelFileName = modelFolder +'/' + train_method['nn_name'] + "/net/" + modelName 
                                trainFileName  = modelFolder +'/' + train_method['nn_name']+ "/train/" + modelName 
                                testFileName  = modelFolder +'/' + train_method['nn_name'] + "/test/" + modelName 
                                
    
                                ###### Training process
                                mylist = {'modelFileName': modelFileName, 
                                            'trainFileName': trainFileName, 
                                            'testFileName': testFileName,
                                            'noise_para':noise_para,
                                            'traj_para' : traj_para,
                                            'train_para':  train_para,
                                            'train_method':  train_method,
                                            'Data_collection':  Data_collection}
                                
                                
                                # for process_id in range(num_processes):
                                #     worker_train(mylist, process_id)
                                    
                                                                
                                
                                if __name__ == '__main__':
                                    
                                    if mp.get_start_method(allow_none=True) is None:
                                        mp.set_start_method('spawn')
                                    
                                    processes = []
                                    
                                    for process_id in range(num_processes): 
                                                                          
                                        process = mp.Process(target=worker_train, args=(mylist, process_id))
                                        process.start()
                                        processes.append(process)
                                    
                                    for process in processes:
                                        process.join()
                                    
                                    
                                   
                                    
                                    
                                    
                                    
                                    
                                    
                                    
                                    
                                    
                                    
                                    
                                    
                                    
                                    
                                    
                                    
                                    
                     


