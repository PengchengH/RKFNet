# -*- coding: utf-8 -*-
"""
Created on Fri Jan  5 15:39:39 2024

@author: hpc
"""

import sys
import os

# add parent directory
current_dir = os.path.abspath(os.getcwd())
parent_dir = os.path.dirname(current_dir)
sys.path.append(parent_dir)


# add tools
sys.path.append(parent_dir+'/tools/tracking_model')
sys.path.append(parent_dir+'/tools/kftncm')
sys.path.append(parent_dir+'/tools/rkfnet')
sys.path.append(parent_dir+'/tools/parallel')
sys.path.append(parent_dir+'/tools/rkf')
sys.path.append(parent_dir+'/tools/stdt')
sys.path.append(parent_dir+'/tools/slash')
sys.path.append(parent_dir+'/tools/vg')
sys.path.append(parent_dir+'/tools/ssg')


import torch
dev = torch.device("cpu")
torch.set_default_tensor_type('torch.DoubleTensor')
print("Running on the CPU")
# dev = torch.device("cuda:0") 
# torch.set_default_tensor_type('torch.cuda.DoubleTensor')
# print("Running on the GPU")
torch.pi = torch.acos(torch.zeros(1)).item() * 2 # which is 3.1415927410125732
from Transfer_data import  DataLoader
from worker import worker_train, worker_test
import torch.multiprocessing as mp
import matplotlib.pyplot as plt



# Constant parameters
# modelFolder = parent_dir + '/RNNs_training_result/'
modelFolder = 'result/'

num_processes = 5

#######################################
### Matrices for different scenario ###
#######################################
#state-space model
Filters = ['kftncm','stdt','slash','ssg']

noise = {'noise_index': ['gm', 'stdt', 'ssg'],
          'dof_index':[[3, 10, 100, 1000, 10000, 100000, 1000000, 10000000, 100000000],
                       [0.3, 0.5, 0.7, 0.9, 1.2, 1.7, 2.5, 3.5, 6],
                       [0.3, 0.5, 0.7, 0.9, 1.1, 1.3, 1.5, 1.7, 1.85]] }

#Training method
Loss_select   = ['L1', 'L2', 'ST']
P_truth_index = [0.0, 0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1.0]
train_mode    = ['NSS','SS']

# parameters for RKF-SGaS
num_series   = 30 
num_particle = 100

# Number of lengthraining Examples, CV and Test
train_para = {}
train_para['n_Epochs'] = 2000
train_para['n_Batch']  = 200 

train_para['learningRate'] = 2e-4

train_para['weightDecay']  = 1e-4
train_para['N_E']  = 3200
train_para['N_CV'] = 200
train_para['N_T']  = 200

# Parameter of neural networks
nn_para = {'name': ['HRKFnn', 'MB_vanilla_RNN','MB_GRU','MB_LSTM'],
           'HRKFnn': {'H0':5, 'H1':32, 'H2':64, 'H3':32, 'H4':1},
           'MB_vanilla_RNN':{'H0':2, 'H1':63, 'H2':4, 'layer':1},
           'MB_GRU':  {'H0':2, 'H1':36, 'H2':4, 'layer':1}, 
           'MB_LSTM': {'H0':2, 'H1':31, 'H2':4, 'layer':1} }


Td = {'RKFnet': {'RMSE_p': torch.zeros(len(noise['noise_index']), len(nn_para['name']),len(noise['dof_index'][2]),num_processes),
                 'MAE_p' : torch.zeros(len(noise['noise_index']), len(nn_para['name']),len(noise['dof_index'][2]),num_processes),
                 'RMSE_v': torch.zeros(len(noise['noise_index']), len(nn_para['name']),len(noise['dof_index'][2]),num_processes),
                 'MAE_v' : torch.zeros(len(noise['noise_index']), len(nn_para['name']),len(noise['dof_index'][2]),num_processes)},
      
      }
    
    
for index_filter in range(3,4):
    for index_noise in range(0,3):
        for index_dof in range(0,9):  
            
            # Noise environment
            noise_name = noise['noise_index'][index_noise]
            dof        = noise['dof_index'][index_noise][index_dof]
            
            noise_para   = {'noise_name':noise_name, 'dof': dof}
            

            ###############################################################
            ### Download or Generate Target Trajectory and Measurements ###
            ###############################################################
            trajFolderName = parent_dir + '/' + 'traj' + '/'            
            trajName       = 'ns_' + noise_name + '_tail_' + str(dof)  
            trajFileName   = trajFolderName + trajName + '.mat'
            
            dataFolderName = parent_dir + '/RKF_filtering_data' + '/' + Filters[index_filter] + '/'
            
            if Filters[index_filter] == 'ssg' :
                dataName = 'ns_'+ noise_name +'_tail_' + str(dof) + '_IGIS_npar_100'
            else:
                dataName = 'ns_'+ noise_name +'_tail_' + str(dof) 
            
            dataFileName = dataFolderName + dataName + '.mat'          
            
            print("Traj Load")
                    
            [Data_collection, md_para, traj_para] = DataLoader(Filters[index_filter], trajFileName, dataFileName, train_para)
                 
            
            
            ###############################
            ###  Neural network methods ###
            ###############################                
            train_method = {}
   
            for index_nn in range(0,4):
                for index_Loss in range(2,3):
                    for index_p in range(0,1):
                        for index_mode in range(1,2):  
                            
                            if (train_mode[index_mode] == 'NSS' and P_truth_index[index_p] == 0.0) or \
                                  train_mode[index_mode] == 'SS':
                                    
                                train_method = {'Filter':Filters[index_filter],
                                                'noise' :noise['noise_index'][index_noise],
                                                'dof'   :noise['dof_index'][index_noise][index_dof],
                                                'nn_name': nn_para['name'][index_nn],
                                                'nn_para': nn_para[nn_para['name'][index_nn]],
                                                'Loss':Loss_select[index_Loss],
                                                'P_mini':P_truth_index[index_p],
                                                'train_mode':train_mode[index_mode]} 
                                
                                # print(train_method ) 
                                
                                
                                modelName  =  train_method['train_mode'] + '_' + 'pmin' + str(train_method['P_mini']) + '_' + train_method['Loss'] \
                                                    + '_md_' + train_method['Filter'] + '_ns_' + train_method['noise']+ '_dof'+ str(train_method['dof'])
                                modelFileName = modelFolder +'/' + train_method['nn_name'] + "/net/" + modelName 
                                trainFileName  = modelFolder +'/' + train_method['nn_name']+ "/train/" + modelName 
                                testFileName  = modelFolder +'/' + train_method['nn_name'] + "/test/" + modelName 
                                
    
                                ###### Training process
                                mylist = {'modelFileName': modelFileName, 
                                            'trainFileName': trainFileName, 
                                            'testFileName': testFileName,
                                            'noise_para':noise_para,
                                            'traj_para' : traj_para,
                                            'train_para':  train_para,
                                            'train_method':  train_method,
                                            'Data_collection':  Data_collection}
                                
                                for process_id in range(num_processes):
                                
                                    # load results
                                    # test_result = torch.load(testFileName+ '_ID_'+ str(process_id)+ '.pt')
                                    # Td['RKFnet']['RMSE_p'][index_noise, index_nn, index_dof, process_id] = test_result['test_sum']['RMSE_p']
                                    train_result = torch.load(trainFileName + '_ID_'+ str(process_id)+ '.pt')
                                    Td['RKFnet']['RMSE_p'][index_noise, index_nn, index_dof, process_id] = train_result['cv_sum']['opt']['RMSE_p']
                                
                                    
# min
fig, axs = plt.subplots(3, 1, figsize=(12, 12))

fig.text(0.5, 0.01, "Shape Parameter Index", ha='center', fontsize=20)
fig.text(0.01, 0.5, 'log10(RMSE(m))', va='center', rotation='vertical', fontsize=20)

dof_index = torch.arange(0, len(noise['dof_index'][index_noise]),1)

plt.subplot(311)
plt.plot(dof_index,torch.log10(torch.min(Td['RKFnet']['RMSE_p'][0,0,:,:],1).values),'r--', linewidth=3.0, markersize=14)
plt.plot(dof_index,torch.log10(torch.min(Td['RKFnet']['RMSE_p'][0,1,:,:],1).values),'b--', linewidth=3.0, markersize=14)
plt.plot(dof_index,torch.log10(torch.min(Td['RKFnet']['RMSE_p'][0,2,:,:],1).values),'g--', linewidth=3.0, markersize=14) 
plt.plot(dof_index,torch.log10(torch.min(Td['RKFnet']['RMSE_p'][0,3,:,:],1).values),'y--', linewidth=3.0, markersize=14)  
plt.legend(['HRKFnn', 'MB_vanilla_RNN','MB_GRU','MB_LSTM'], fontsize=16)
plt.title('GM', fontsize=16)
plt.xticks(fontsize=16)
plt.yticks(fontsize=16)


plt.subplot(312)
plt.plot(dof_index,torch.log10(torch.min(Td['RKFnet']['RMSE_p'][1,0,:,:],1).values),'r--', linewidth=3.0, markersize=14)
plt.plot(dof_index,torch.log10(torch.min(Td['RKFnet']['RMSE_p'][1,1,:,:],1).values),'b--', linewidth=3.0, markersize=14)
plt.plot(dof_index,torch.log10(torch.min(Td['RKFnet']['RMSE_p'][1,2,:,:],1).values),'g--', linewidth=3.0, markersize=14) 
plt.plot(dof_index,torch.log10(torch.min(Td['RKFnet']['RMSE_p'][1,3,:,:],1).values),'y--', linewidth=3.0, markersize=14) 
plt.legend(['HRKFnn', 'MB_vanilla_RNN','MB_GRU','MB_LSTM'], fontsize=16)
plt.title('ST', fontsize=16)
plt.xticks(fontsize=16)
plt.yticks(fontsize=16)


plt.subplot(313)
plt.plot(dof_index,torch.log10(torch.min(Td['RKFnet']['RMSE_p'][2,0,:,:],1).values),'r--', linewidth=3.0, markersize=14)
plt.plot(dof_index,torch.log10(torch.min(Td['RKFnet']['RMSE_p'][2,1,:,:],1).values),'b--', linewidth=3.0, markersize=14)
plt.plot(dof_index,torch.log10(torch.min(Td['RKFnet']['RMSE_p'][2,2,:,:],1).values),'g--', linewidth=3.0, markersize=14) 
plt.plot(dof_index,torch.log10(torch.min(Td['RKFnet']['RMSE_p'][2,3,:,:],1).values),'y--', linewidth=3.0, markersize=14)  
plt.legend(['HRKFnn', 'MB_vanilla_RNN','MB_GRU','MB_LSTM'], fontsize=16)
plt.title(r'SG$\alpha$S', fontsize=16)
plt.xticks(fontsize=16)
plt.yticks(fontsize=16)

plt.subplots_adjust(left=0.075, right=0.95, top=0.95, bottom=0.075, wspace=0.18, hspace=0.2)

plt.savefig(modelFolder + 'train_RNNs_analysis' +'.png')                                 
                                    
                                    
                                    
                                    
                                    
                                    
                                    
                                    
                                    
                                    
                                    
                                    
                                    
                                    
                                    
                                    
                                    
                     


